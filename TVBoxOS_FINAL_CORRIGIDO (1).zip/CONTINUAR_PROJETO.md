# CONTINUAR_PROJETO.md — TVBox OS

> Leia este arquivo por inteiro antes de escrever qualquer código novo.
> Ele descreve o estado REAL do código, não o que foi apenas planejado.

## 0. Status da verificação de build (leia isto primeiro)

### Atualização — primeiro build real (GitHub Actions, 23/11/2026) e auditoria
- O primeiro build real passou por: download do Gradle 8.4, resolução dos plugins (AGP 8.2.2, Kotlin
  1.9.22, KSP), merge do manifesto e `checkDebugAarMetadata` (compatibilidade das dependências com
  `compileSdk 33`). Falhou em `:app:processDebugResources` por causa de **dois erros em
  `activity_login.xml`** (namespace `xmlns:app` errado + atributo `layoutManagerOrientation`
  inexistente). Isso foi corrigido (ver `AUDITORIA_TVBOX_OS.md`).
- **Ainda NÃO confirmado por build real:** compilação Kotlin, KSP/Room, D8, testes JVM e geração do
  APK — o build anterior parou antes dessas etapas. O próximo run do Actions é o teste de verdade.
- Se aparecer um novo erro, cole o log aqui e em `AUDITORIA_TVBOX_OS.md`.
- Verificação estática rápida (sem Gradle): `python3 tools/check_project.py .`
- Teste de regressão novo: `ResourceSanityTest` (namespaces e prefixos dos XMLs de recursos).


Este ambiente de desenvolvimento (sandbox usado para gerar o projeto) **não
tem acesso de rede aos servidores do Gradle, do Google Maven (`dl.google.com`)
nem do Maven Central** — só a uma lista fixa de domínios (GitHub, npm, PyPI,
crates.io, Ubuntu). Isso foi testado diretamente:

```
curl https://services.gradle.org/...   -> "Could not resolve host"
curl https://dl.google.com/...         -> "Could not resolve host"
curl https://repo.maven.apache.org/... -> "Could not resolve host"
```

Por isso, **não foi possível rodar `./gradlew assembleDebug` de verdade nem
gerar um APK real** neste ambiente — faltam o próprio Gradle, o Android SDK
(android.jar, build-tools, d8/r8) e as dependências (AndroidX, Room, Material).
Nenhum desses pode ser baixado aqui. **Nenhum APK foi gerado nem incluído no
ZIP**, para não entregar um arquivo falso ou quebrado.

### Gradle Wrapper: incluído e testado até onde a rede permite
`gradlew`, `gradlew.bat` e `gradle/wrapper/gradle-wrapper.jar` são os arquivos
**oficiais do projeto Gradle**, baixados da tag `v8.4.0` do repositório oficial
`gradle/gradle` no GitHub (domínio liberado neste ambiente, ao contrário dos
servidores de distribuição do Gradle/Maven). Eles batem exatamente com a
versão `8.4` já configurada em `gradle/wrapper/gradle-wrapper.properties`.

Rodei `./gradlew --version` neste ambiente para confirmar que o wrapper em si
funciona: ele leu o JDK 21 instalado aqui, leu corretamente o
`gradle-wrapper.properties`, e tentou baixar a distribuição do Gradle 8.4 —
falhando **exatamente e apenas** nesse download, com
`UnknownHostException: services.gradle.org` (o mesmo bloqueio de rede descrito
acima, não um defeito nos arquivos do wrapper). Isso é uma boa evidência de
que, em uma máquina com internet normal (sua máquina, o Android Studio, ou o
GitHub Actions), o wrapper vai baixar o Gradle 8.4 sozinho e prosseguir.

### GitHub Actions
Foi adicionado `.github/workflows/android-build.yml`, que:
- usa `actions/setup-java@v4` com **`java-version: "17"`** — compatível com o
  projeto, que define `sourceCompatibility`/`targetCompatibility`/`jvmTarget`
  como 17 em `app/build.gradle.kts`, e com o Android Gradle Plugin 8.2.2 do
  `build.gradle.kts` raiz (AGP 8.x exige JDK 17 para rodar o próprio Gradle);
- usa `android-actions/setup-android@v3` para instalar o Android SDK no runner
  (o `compileSdk 33` do projeto);
- roda `./gradlew assembleDebug` e publica o APK gerado como artefato do
  workflow (`actions/upload-artifact@v4`).
Esse workflow **não foi executado de verdade** (não há GitHub Actions dentro
deste sandbox) — ele foi revisado manualmente (versões de JDK/AGP/compileSdk
coerentes entre si) mas só uma execução real no GitHub confirma 100%.

O que FOI verificado, sem precisar do Gradle/Android SDK:
- Todos os arquivos `.xml` do projeto são bem formados (`xmllint --noout` em
  cada um, sem erros).
- Todas as referências `R.id`, `R.layout`, `R.string`, `R.drawable`, `R.menu`,
  `R.color` usadas nos arquivos `.kt` têm um recurso correspondente definido
  em algum XML (checagem automatizada, cruzando os dois lados) — nenhuma
  referência quebrada encontrada.
- Chaves `{}`, parênteses `()` e colchetes `[]` de cada arquivo `.kt` estão
  balanceados (checagem automatizada).
- O `package` declarado em cada arquivo `.kt` bate com a pasta onde ele está.
- Corrigido durante essa revisão: `AppDatabase.kt` usa `exportSchema = true`,
  mas faltava configurar `room.schemaLocation` no KSP — isso causaria aviso/erro
  do Room no primeiro build real. Foi adicionado em `app/build.gradle.kts`
  (bloco `ksp { arg("room.schemaLocation", ...) }`) e criada a pasta
  `app/schemas/`.

O que **NÃO** foi e não pôde ser verificado aqui (só é possível com o Android
Studio/Gradle reais, que têm o toolchain completo):
- Resolução de tipos do Kotlin contra as APIs reais do Android/AndroxX/Room
  (ex.: assinatura exata de métodos, nulabilidade). A revisão manual do código
  seguiu os padrões usuais dessas APIs, mas só o compilador Kotlin real, com
  `android.jar` e os `.jar`/`.aar` das bibliotecas, confirma 100%.
- Processamento de anotações do Room via KSP (geração do `DAO_Impl`, etc.).
- Empacotamento final em APK (D8/R8, assinatura, merge de manifests/recursos).

**Ação recomendada para você**: abra o projeto no Android Studio (que tem
acesso normal à internet) e rode a sincronização do Gradle + `Build > Build
APK(s)`. Se aparecer algum erro de compilação real nesse momento (algo que só
o compilador completo detectaria), ele quase certamente será pequeno — a
estrutura, os nomes de pacotes e as referências de recursos já foram
validados como descrito acima.

### Status de build na ETAPA 2 (leia)
O ambiente em que a Etapa 2 foi escrita continuou **sem rede** (Gradle/Maven/Google
bloqueados e sem Android SDK), então **nada da Etapa 2 foi compilado nem executado**:
nem o app, nem os testes JVM, nem os testes instrumentados. Foram feitas apenas as
verificações estáticas descritas acima (XML bem formado com `xmllint`, referências
`R.*` cruzadas em ambos os lados, chaves/parênteses balanceados). O primeiro
`./gradlew testDebugUnitTest assembleDebug` real (GitHub Actions ou Android Studio)
continua sendo o teste de fumaça pendente — registre aqui qualquer erro que aparecer.
## 1. Nome do projeto
TVBox OS — launcher Android com visual inspirado no Windows 11 para TV Box.

## 2. Versão atual
`0.2.0-etapa2` (`versionCode = 2`). Etapa 1 concluída; **Etapa 2 implementada no código
mas ainda não compilada/testada em aparelho** (ver seção 0). Etapas 3, 4 e 5 NÃO iniciadas.

## 3. O que já foi desenvolvido (verificado no código, não apenas planejado)

### Estrutura do projeto
- Projeto Gradle (Kotlin DSL) com módulo único `app`.
- `compileSdk 33`, `minSdk 29` (Android 10, hardware-alvo), `targetSdk 30`.
- Arquitetura em pacotes: `data` (Room + repositório), `util`, `login`, `desktop`.
- ViewBinding habilitado; sem Jetpack Compose (mantém app leve para Mali-450/4GB RAM).

### Sistema de perfis (item 3 do briefing)
- Entidade `Profile` (Room) com nome, avatar (emoji), hash+salt de senha (SHA-256),
  caminho de papel de parede e data de criação.
- `ProfileRepository`: criar, editar (nome/avatar/senha), excluir e verificar senha.
- Senha **nunca** é guardada em texto puro — apenas hash com salt aleatório
  (`util/PasswordUtils.kt`).
- `LoginActivity`: tela de seleção de usuário com lista horizontal de perfis,
  botão "Criar perfil", clique longo / clique direito do mouse abre menu
  (Editar perfil / Excluir perfil), diálogo de senha quando o perfil tem senha.
- `SessionManager`: guarda o perfil logado em `SharedPreferences`, sobrevive a
  reabertura do app; "Bloquear sessão" e "Trocar usuário" limpam a sessão.

### Isolamento entre perfis
- Ícones da área de trabalho (`DesktopIconEntity`) têm `profileId` e são
  sempre filtrados por perfil (`DesktopIconDao.observeForProfile`), então os
  atalhos de um perfil realmente não aparecem para outro.
- **Limitação documentada e REAL (não escondida)**: o Android não permite que
  um app comum isole os dados internos de OUTROS aplicativos entre "perfis"
  criados dentro do próprio launcher — todos os apps instalados continuam
  rodando sob a mesma conta do Android. Isso está explicado:
  - No código: comentário em `data/Profile.kt`.
  - Para o usuário: string `login_delete_warning`, mostrada no diálogo de
    exclusão de perfil em `LoginActivity.kt`.

### Área de trabalho (item 4) e barra de tarefas (item 10)
- `DesktopActivity`: grade de ícones (`GridLayoutManager`, 6 colunas) carregada
  via `Flow` do Room, atualiza automaticamente quando um ícone é adicionado/
  removido/renomeado.
- Barra de tarefas fixa embaixo: botão Iniciar, relógio (atualiza a cada 15s),
  ícone de Wi-Fi (opacidade muda conforme `ConnectivityManager` reporta
  internet ativa ou não — estado real do sistema, não simulado).
- Adicionar app ao desktop: `AddAppDialog` lista os apps instalados de verdade
  via `PackageManager` (`InstalledAppsProvider`) e grava um
  `DesktopIconEntity` associado ao perfil atual.
- Abrir um ícone de app dispara uma `Intent` explícita real
  (`InstalledAppsProvider.buildLaunchIntent`).
- Criar pasta: grava uma entrada `IconType.FOLDER` no banco (o CONTEÚDO da
  pasta ainda não é navegável — ver seção 5).

### Menu do botão direito (item 5)
- Clique direito do mouse (ou toque longo) em área vazia do desktop ->
  `menu_desktop_empty` (Adicionar aplicativo / Nova pasta / Atualizar),
  implementado via `registerForContextMenu` (funciona com mouse USB real,
  não é um gesto simulado).
- Clique direito em um ícone -> `menu_desktop_icon` (Abrir / Renomear /
  Remover da área de trabalho / Propriedades), via `PopupMenu` ancorado no
  ícone.
- Todos os itens desses menus executam ações reais (gravam/leem do Room,
  ou chamam `startActivity`), nenhum é apenas visual.

### Identidade visual (item 2)
- Tema claro/escuro (`values/themes.xml` + `values-night/themes.xml`),
  paleta neutra inspirada no Windows 11 (`values/colors.xml`), sem neon.
- Cantos arredondados em cartões/diálogos (`drawable/bg_card_light.xml`),
  ícone do app em vetor (sem depender de editor de imagem externo).

### ETAPA 2 — implementado (código escrito; build e testes em aparelho pendentes)
- **Menu Iniciar completo** (`DesktopActivity` + `activity_desktop.xml`, painel `startMenuOverlay`):
  lista de TODOS os apps instalados (launcher + leanback, sem o próprio TVBox OS), campo de busca
  que ignora acento/maiúsculas (`util/SearchNormalizer`; quem começa com o texto vem primeiro),
  rodapé com avatar/nome do perfil, **Personalizar**, **Trocar usuário** e **Bloquear sessão**.
  Fecha com o botão Iniciar, toque fora ou Voltar. Clique longo/direito num app: Abrir,
  Fixar na área de trabalho, Informações do aplicativo (tela real de detalhes do Android).
  A lista atualiza sozinha ao instalar/remover apps (`BroadcastReceiver` PACKAGE_ADDED/REMOVED).
- **Papel de parede real via SAF** (`ActivityResultContracts.OpenDocument`): a imagem é copiada
  para `filesDir/profiles/<id>/`, reduzida a no máx. 1920x1080 (JPEG), com rotação EXIF corrigida
  (`util/ImageStorage`, `util/ImageMath`). Exibido em RGB_565 (metade da RAM). Texto dos ícones
  fica branco com sombra quando há foto. Botão "Restaurar padrão".
- **Avatar por foto da galeria**: na tela "Personalizar" (perfil logado) e também ao criar/editar
  perfil no login. Recorte quadrado central 256x256. Sem foto, continua o emoji. Aparece no login,
  no Menu Iniciar e nas prévias.
- **Arrastar e reordenar ícones**: `ItemTouchHelper` (`desktop/IconDragCallback`) ligado ao campo
  `position`; ao soltar, `IconOrder.renumber` + `ProfileRepository.saveIconOrder`. Segurar e soltar
  SEM mover abre o menu do ícone (comportamento antigo do toque longo). Para controle remoto/teclado:
  itens "Mover para trás/frente" no menu do ícone (abre com clique direito ou tecla MENU).
- **Banco**: Room v2, migração `MIGRATION_1_2` (coluna `avatarImagePath`), sem destruir dados.
  Updates pontuais (`setWallpaperPath`, `setAvatarImagePath`) para não sobrescrever o perfil com cópia velha.
- **Pendências técnicas tratadas**: (1) `InstalledAppsProvider.list()` agora é `suspend` em
  `Dispatchers.Default`; ícones carregados sob demanda por `AppIconLoader` (cache LRU de 64);
  (2) `DesktopIconAdapter` e `ProfileAdapter` usam `DiffUtil` (sem `notifyDataSetChanged`);
  (3) testes escritos (seção 6b); (4) compatibilidade revisada (seção 9b).
- **Bugs corrigidos de passagem**: "Atualizar" no menu da área de trabalho criava um coletor de
  Flow duplicado a cada clique (agora cancela o anterior); `<queries>` no manifesto para a lista
  de apps não vir incompleta no Android 11+.
## 4. Funcionalidades PARCIALMENTE implementadas
- **Pastas na área de trabalho**: criadas e exibidas, mas clicar só mostra aviso; abrir o conteúdo
  depende do Explorador de Arquivos (Etapa 3).
- **Seletor de imagens (SAF)**: depende do app *DocumentsUI* do Android. Algumas TV boxes baratas
  NÃO o trazem; nesse caso o app mostra um aviso (não quebra). A solução definitiva é o Explorador
  de Arquivos próprio (Etapa 3) servir de seletor de imagem. **Precisa ser conferido na TV Box real.**
- **Barra de tarefas**: `taskbarAppsContainer` existe mas segue vazio (janelas internas = Etapa 4).
## 5. Funcionalidades ainda NÃO desenvolvidas
- **ETAPA 3**: Explorador de arquivos (navegar, criar, abrir, renomear, copiar, mover, excluir),
  editor de texto, criar/salvar documentos, abrir pastas da área de trabalho.
- **ETAPA 4**: Configurações completas, janelas internas (minimizar/maximizar/restaurar/fechar),
  gerenciador de downloads, instalação de APK (FileProvider + `PackageInstaller`/`ACTION_VIEW` com
  `REQUEST_INSTALL_PACKAGES`, já declarada no manifesto).
- **ETAPA 5**: otimização para Android 10/ARM64/4 GB/Mali-450, testes em TV Box real, correção de
  bugs, `signingConfigs` de release (keystore), APK final assinado. **Exige aparelho físico.**
## 6. Bugs conhecidos / pontos de atenção
- **Nada foi compilado ainda** (seção 0). Esperar pequenos erros de compilação no primeiro build.
- Falha ao abrir o Room (disco cheio etc.) ainda derrubaria o app (sem tratamento).
- Pasta `app/schemas/` só terá `2.json` após o primeiro build; commitar o arquivo gerado.
  (Não existe `1.json` porque a versão 1 nunca foi compilada; por isso o teste de migração usa SQLite
  puro em vez do `MigrationTestHelper`.)
- Ícones de apps de TV (leanback) usam o ícone da atividade; alguns apps só têm "banner" — hoje
  mostramos o ícone que o PackageManager devolve.
- Senha ainda é SHA-256 + salt (aceitável para uso doméstico; PBKDF2 seria melhor — avaliar na Etapa 5).
- Avatar é lido do disco de forma síncrona (arquivo de 256x256, cache LRU); papel de parede é lido em IO.

### 6b. Testes escritos (NÃO executados neste ambiente)
JVM (`app/src/test`, rodam no GitHub Actions em `testDebugUnitTest`): `SearchNormalizerTest`,
`IconOrderTest`, `ImageMathTest`, `PasswordUtilsTest`, `DesktopIconDiffTest`.
Instrumentados (`app/src/androidTest`, exigem aparelho/emulador, `connectedDebugAndroidTest`):
`DesktopIconDaoTest` (Room: ordem, isolamento por perfil, persistência do arrastar, updates pontuais),
`MigrationTest` (1→2 preserva dados), `InstalledAppsProviderTest`, `StartMenuTest` (Espresso: abrir/fechar
menu e busca sem resultado). **Testes de UI do arrastar (ItemTouchHelper) e do SAF não foram escritos**
— precisam de verificação manual na TV Box (checklist na seção 12).
## 7. Arquivos principais e suas funções
```
app/src/main/java/com/tvboxos/launcher/
  App.kt                         -> Application; expõe repository e session globalmente
  data/Profile.kt                -> entidade do perfil (com comentário sobre limites de isolamento)
  data/DesktopIconEntity.kt      -> entidade de ícone/atalho por perfil
  data/ProfileDao.kt             -> queries Room de perfis
  data/DesktopIconDao.kt         -> queries Room de ícones
  data/AppDatabase.kt            -> banco Room (singleton)
  data/ProfileRepository.kt      -> regra de negócio (único ponto de acesso a dados)
  data/SessionManager.kt         -> perfil logado atualmente (SharedPreferences)
  util/PasswordUtils.kt          -> hash de senha (SHA-256 + salt)
  util/AvatarProvider.kt         -> lista de avatares fixos (emoji)
  login/LoginActivity.kt         -> tela de seleção de usuário
  login/ProfileAdapter.kt        -> RecyclerView.Adapter da lista de perfis
  login/CreateProfileDialog.kt   -> diálogo de criar/editar perfil + escolha de avatar
  login/PasswordPromptDialog.kt  -> diálogo de senha ao entrar num perfil
  desktop/DesktopActivity.kt     -> área de trabalho + barra de tarefas do perfil logado
  desktop/DesktopIconAdapter.kt  -> RecyclerView.Adapter da grade de ícones
  desktop/InstalledAppsProvider.kt -> lista apps instalados via PackageManager
  desktop/AddAppDialog.kt        -> diálogo "Adicionar aplicativo" (lista em coroutine)
  desktop/AppListAdapter.kt      -> lista de apps (Menu Iniciar + diálogo), DiffUtil
  desktop/AppIconLoader.kt       -> ícones sob demanda + cache LRU
  desktop/IconDragCallback.kt    -> ItemTouchHelper (arrastar/reordenar ícones)
  desktop/PersonalizeDialog.kt   -> papel de parede e foto do perfil
  util/SearchNormalizer.kt       -> busca sem acento (lógica pura, testada)
  util/IconOrder.kt              -> mover/renumerar `position` (lógica pura, testada)
  util/ImageMath.kt              -> amostragem/recorte de imagem (puro, testado)
  util/ImageStorage.kt           -> copia/reduz imagens do SAF para o armazenamento do perfil
  util/AvatarView.kt             -> mostra foto ou emoji do perfil
```

## 8. Tecnologias utilizadas
- Kotlin, Android SDK (Gradle Kotlin DSL).
- Room (SQLite) para perfis e ícones.
- SharedPreferences para a sessão atual.
- ViewBinding, RecyclerView, Material Components.
- Sem bibliotecas de terceiros além do ecossistema AndroidX/Google.

## 9. Dependências necessárias para compilar
- Android Studio (recomendado: versão recente com suporte a AGP 8.2.x) **ou**
  apenas um JDK 17 + internet, usando o wrapper incluído.
- JDK 17 (configurado em `compileOptions`/`kotlinOptions`; é também o que o
  workflow do GitHub Actions usa).
- Acesso à internet na primeira sincronização do Gradle (baixa a distribuição
  do Gradle 8.4, o AGP, Kotlin, AndroidX, Room, KSP — todos do
  `google()`/`mavenCentral()`, sem repositórios privados).
- **Gradle Wrapper**: `gradlew`, `gradlew.bat` e
  `gradle/wrapper/gradle-wrapper.jar` **já estão incluídos neste ZIP**
  (arquivos oficiais do Gradle 8.4, obtidos do repositório `gradle/gradle` no
  GitHub). Não é mais necessário abrir no Android Studio só para gerá-los —
  `./gradlew assembleDebug` funciona direto em qualquer máquina com JDK 17 e
  internet, e também é o que o workflow do GitHub Actions usa.

### 9b. Revisão de compatibilidade (Pendência técnica 4)
| Item | Versão | Situação |
|---|---|---|
| Gradle | 8.4 (wrapper) | OK com AGP 8.2.2 (exige ≥ 8.2). **Roda em JDK ≤ 20**: JDK 21 local NÃO serve para o Gradle 8.4 — use JDK 17. |
| AGP | 8.2.2 | Exige JDK 17 (workflow usa Temurin 17). Testado oficialmente até compileSdk 34. |
| Kotlin / KSP | 1.9.22 / 1.9.22-1.0.17 | Par exato (KSP precisa casar com o Kotlin). |
| Room | 2.5.2 (KSP) | OK. `room.schemaLocation` configurado. |
| compileSdk / minSdk / targetSdk | 33 / 29 / 30 | compileSdk 33 satisfaz Material 1.9.0, core-ktx 1.10.1, lifecycle 2.6.2. minSdk 29 = Android 10 (alvo). |
| JDK de compilação | 17 | `compileOptions` e `jvmTarget` = 17 coerentes. |
Ajustes feitos: `rootProject.buildDir` (obsoleto) → `layout.buildDirectory`; `unitTests.isReturnDefaultValues`;
dependências de teste e `exifinterface 1.3.6`; workflow ganhou cache do Gradle e passo `testDebugUnitTest`.
Observação: `targetSdk 30` mantém o comportamento de armazenamento mais permissivo — bom para o Explorador
de Arquivos (Etapa 3), mas a instalação de APK precisará do fluxo oficial de "fontes desconhecidas".
## 10. Como abrir o projeto
Veja `README.md` na raiz do projeto — passo a passo completo de abertura,
compilação do APK e instalação na TV Box.

## 11. Como compilar o APK
```
./gradlew assembleDebug
```
Gera `app/build/outputs/apk/debug/app-debug.apk`. Ainda não há configuração de
assinatura de release (`signingConfigs`) — isso está planejado para a Etapa 5,
junto com a geração do APK final.

## 12. Qual deve ser a próxima tarefa
1. **Rodar o primeiro build real** (`./gradlew testDebugUnitTest assembleDebug` no GitHub Actions) e corrigir
   o que o compilador/Room/KSP apontarem. Commitar `app/schemas/.../2.json` gerado.
2. **Checklist manual da Etapa 2 na TV Box/emulador** (nada disso foi testado ainda):
   - Menu Iniciar abre/fecha (botão, toque fora, Voltar); busca "camera" acha "Câmera"; lista mostra apps de TV.
   - Fixar app na área de trabalho pelo Menu Iniciar; abrir app pelo Menu Iniciar.
   - Personalizar → escolher papel de parede (foto grande, foto girada); reabrir o app; trocar de perfil
     (cada perfil mantém o seu); restaurar padrão.
   - Foto do avatar pelo Personalizar e pelo Editar perfil; remover foto volta ao emoji.
   - Arrastar ícone com mouse e com toque; fechar/abrir o app e conferir que a ordem persistiu;
     "Mover para trás/frente" com controle remoto; clique direito abre o menu.
   - Em aparelho SEM DocumentsUI: confirmar que aparece o aviso em vez de travar.
3. Só depois, **ETAPA 3** (Explorador de arquivos + editor de texto). Etapas 4 e 5 em seguida.

Ao concluir cada passo, gerar novo ZIP do projeto completo e atualizar as seções 2, 3, 4 e 12.
