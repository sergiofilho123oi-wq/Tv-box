# Auditoria do projeto TVBox OS

Data: 23/11/2026 · Versão auditada: `0.2.0-etapa2`

## 1. Resultado real (leia primeiro)

| Critério pedido | Status |
|---|---|
| `./gradlew clean testDebugUnitTest assembleDebug` termina com BUILD SUCCESSFUL | **NÃO VERIFICADO.** Não pude executar o Gradle aqui. |
| APK gerado | **NÃO VERIFICADO.** Nenhum APK foi gerado nem incluído no ZIP. |
| Arquivos de teste presentes | Sim: 6 arquivos de testes JVM (5 originais + `ResourceSanityTest`) e 4 instrumentados. |
| Workflow do GitHub Actions configurado | Sim, revisado e com YAML válido, **mas ainda não executado**. |
| Sem erros de compilação pendentes | **NÃO DÁ PARA AFIRMAR.** A compilação Kotlin nunca rodou (nem aqui, nem no CI). |

**Por que não consegui compilar:** este ambiente não tem rede (testei Gradle, Google Maven, Maven Central e GitHub: todos sem resposta), nem Android SDK, nem compilador Kotlin. Nada foi compilado nem executado. O que segue é auditoria estática mais a evidência do seu log real do GitHub Actions.

## 2. Evidência do log real (run de 23/11/2026, 23:19 UTC)

Passaram: JDK 17 (Temurin 17.0.21), Android SDK + licenças + `platforms;android-33`, download do Gradle 8.4, configuração do build (AGP 8.2.2, Kotlin 1.9.22, KSP), merge do manifesto e `checkDebugAarMetadata` (dependências compatíveis com `compileSdk 33`).

Falhou: `:app:processDebugResources`, com exatamente dois erros, ambos em `activity_login.xml`:

```
activity_login.xml:33: error: attribute app:layoutManager not found.
activity_login.xml:33: error: attribute app:layoutManagerOrientation not found.
```

**Não chegaram a rodar:** `kspDebugKotlin`, `compileDebugKotlin`, D8, testes e empacotamento. Os erros que existirem nessas etapas ainda são desconhecidos.

## 3. Problemas encontrados e correções

### 3.1 Causa real do erro do RecyclerView (bloqueante, confirmado pelo CI)
- **Onde:** `app/src/main/res/layout/activity_login.xml`, linha 3 e linhas 32–33.
- **Causa:** o namespace estava `xmlns:app="http://schemas.android.com/apk/res/app"`. O correto para atributos de bibliotecas é `.../res-auto`. Com o namespace errado, o aapt2 não encontra `app:layoutManager`. Além disso, `app:layoutManagerOrientation` não existe em nenhuma versão do RecyclerView.
- **Correção:** removido o `xmlns:app` e os dois atributos `app:` do `RecyclerView`, e também o `android:orientation`, que não tinha efeito. A orientação horizontal já é definida no código, em `LoginActivity.kt`: `LinearLayoutManager(this, HORIZONTAL, false)`. Nenhuma funcionalidade foi removida. Foi conferido que nenhum outro XML usa o namespace errado.

### 3.2 Correções preventivas (não confirmadas como erro)
- `util/ImageStorage.kt`: a variável local `final` (palavra-chave modificadora do Kotlin) foi renomeada para `scaledAvatar`. Provavelmente compilaria, mas não há ganho em arriscar.
- `gradle.properties`: heap do Gradle de 2 GB para 3 GB e `kotlin.daemon.jvmargs=-Xmx2048m`. Kotlin + KSP/Room + D8 num único processo com 2 GB é risco conhecido de `OutOfMemoryError` no CI.
- `gradle/wrapper/gradle-wrapper.properties`: adicionados `networkTimeout` e `validateDistributionUrl`. A versão (8.4) não mudou.
- `.gitignore`: antes só ignorava `/build` da raiz, então `app/build` (milhares de arquivos) entraria no commit. Agora ignora `build/` em qualquer módulo, `.kotlin/`, `*.apk` e `*.aab`.

### 3.3 GitHub Actions
- O log que você enviou veio de **outro workflow**: ele extraía um `.zip` commitado no repositório para `./project`. O workflow deste ZIP espera o projeto **extraído na raiz** e falha cedo, com mensagem clara, se não estiver.
- Novo `.github/workflows/android.yml`: etapa de verificação da estrutura e do wrapper (os 4 arquivos), verificação estática, JDK 17, SDK com licenças aceitas sem interação, e **um único comando de build**: `./gradlew clean testDebugUnitTest assembleDebug --no-daemon --console=plain --stacktrace`. Publica o APK (falha se não existir), o relatório de testes e os schemas do Room mesmo se o build falhar. `actions/setup-java` subiu de v4 para v5, pois o log avisou que a v4 está descontinuada.
- O aviso `Failed to restore gradle-home ... Cache service 400` do log é do serviço de cache do Actions e não afeta o resultado.

### 3.4 Testes e ferramenta adicionados
- `app/src/test/.../ResourceSanityTest.kt`: teste JVM que falharia no estado original (namespace inválido) e passa no corrigido. Foi simulado em Python com a mesma lógica; ainda não rodou no Gradle.
- `tools/check_project.py`: verificação estática (XML bem formado, namespaces, referências `@recurso`, referências `R.*`, `package` x pasta, chaves balanceadas, integridade do wrapper). Roda no CI antes do Gradle.

## 4. O que foi verificado (e como)

| Verificação | Como | Resultado |
|---|---|---|
| 31 XMLs bem formados | script (`ElementTree`) | OK |
| Namespaces e prefixos dos XMLs | script | Original: 1 erro (o do login). Corrigido: OK |
| Referências `@string/@color/@drawable/@style/@id/@layout/@menu/@mipmap` | script | OK |
| Referências `R.*` nos `.kt` (main, test, androidTest) | script; provei que detecta erro injetando uma referência falsa | OK |
| `package` x pasta, chaves/parênteses balanceados | script | OK |
| Wrapper: 4 arquivos, `gradlew` sem CRLF e executável, `.jar` íntegro (46 classes) | `unzip -t`, `file` | OK |
| Versões AGP 8.2.2 / Gradle 8.4 / Kotlin 1.9.22 / KSP 1.9.22-1.0.17 / JDK 17 | leitura + log do CI | Coerentes; Gradle e plugins carregaram no CI |
| Dependências x `compileSdk 33` | `checkDebugAarMetadata` no CI | Passou |
| Leitura de todo o Kotlin (~2.500 linhas) procurando erros de tipo, nulabilidade, imports, APIs | revisão manual | Nada evidente encontrado. **Isso não substitui o compilador.** |
| Valores esperados dos testes JVM existentes (`ImageMath`, `IconOrder`, `SearchNormalizer`, `PasswordUtils`, `DiffUtil`) | conferidos à mão contra o código | Consistentes. **Não executados.** |
| YAML do workflow | `yaml.safe_load` | Válido |

## 5. O que NÃO pôde ser executado

- Download do Gradle e das dependências, `./gradlew` em qualquer tarefa.
- Compilação Kotlin, KSP/Room (geração dos DAOs e de `app/schemas/.../2.json`), D8 e empacotamento do APK.
- Testes JVM (`testDebugUnitTest`) e o novo `ResourceSanityTest`.
- Testes instrumentados (precisam de emulador/aparelho): nunca rodaram.
- Lint, R8 (minificação está desligada) e teste em TV Box real.

## 6. Observações que NÃO alterei (para preservar o comportamento da Etapa 2)

- `allowBackup="true"` no manifesto: o banco com hash das senhas entra em backups do Android. Considere `false`.
- Senha: SHA-256 com salt em uma única rodada, e comparação com `==`. Já documentado no código como proteção básica; para endurecer, usar PBKDF2/Argon2 com migração dos perfis existentes.
- `item_profile.xml`: o ícone de cadeado (`imgLocked`) usa `ic_default_app` e nunca é exibido no código.
- `MigrationTest` valida apenas a string SQL da migração em SQLite puro, não a `Migration` do Room; não há `schemas/1.json`. O `2.json` será gerado no primeiro build: **commite `app/schemas/`**.
- Algumas strings estão fixas no código em vez de em `strings.xml` (toasts em `DesktopActivity`).
- `ImageStorage.loadAvatar` pode decodificar arquivo na thread principal (há cache LRU de 16 itens).

## 7. Próximo passo

1. Extraia este ZIP **na raiz** do repositório, sobrescrevendo os arquivos. Se o repositório tiver um `.zip` do projeto commitado ou um workflow antigo em `.github/workflows/` com outro nome, apague-os: dois workflows rodariam ao mesmo tempo.
2. `git add -A && git commit -m "Corrige activity_login.xml e atualiza CI" && git push`.
3. Veja o run no GitHub Actions. Se falhar de novo (é possível, pois Kotlin/KSP ainda não rodaram), mande o log: a mensagem "What went wrong" mostra exatamente o arquivo e a linha.
4. Se passar, commite `app/schemas/` (baixe o artefato `tvboxos-room-schemas`).
