package com.tvboxos.launcher.util

/** Cálculos puros de redução de imagem (evita estourar a RAM de uma TV box de 4 GB). */
object ImageMath {

    /** Maior potência de 2 que ainda deixa a imagem >= tamanho pedido. */
    fun inSampleSize(srcW: Int, srcH: Int, reqW: Int, reqH: Int): Int {
        if (srcW <= 0 || srcH <= 0 || reqW <= 0 || reqH <= 0) return 1
        var sample = 1
        while (srcW / (sample * 2) >= reqW && srcH / (sample * 2) >= reqH) sample *= 2
        return sample
    }

    /** Dimensões finais que cabem em [maxW]x[maxH] mantendo proporção (nunca amplia). */
    fun fitWithin(w: Int, h: Int, maxW: Int, maxH: Int): Pair<Int, Int> {
        if (w <= 0 || h <= 0) return 1 to 1
        if (w <= maxW && h <= maxH) return w to h
        val scale = minOf(maxW.toDouble() / w, maxH.toDouble() / h)
        return maxOf(1, Math.round(w * scale).toInt()) to maxOf(1, Math.round(h * scale).toInt())
    }

    /** Quadrado central: devolve (x, y, lado). */
    fun centerSquare(w: Int, h: Int): Triple<Int, Int, Int> {
        val side = minOf(w, h)
        return Triple((w - side) / 2, (h - side) / 2, side)
    }
}
