package com.tvboxos.launcher.desktop

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Apps instalados que podem ser abertos, via API oficial (PackageManager).
 * Inclui apps de celular (CATEGORY_LAUNCHER) e de TV (CATEGORY_LEANBACK_LAUNCHER).
 * O ícone NÃO é carregado aqui (ver AppIconLoader): carregar centenas de ícones de
 * uma vez pesaria na RAM de uma TV box.
 */
data class InstalledApp(
    val label: String,
    val packageName: String,
    val activityClassName: String
)

object InstalledAppsProvider {

    /** Roda em Dispatchers.Default: nunca bloqueia a thread principal. */
    suspend fun list(context: Context): List<InstalledApp> = withContext(Dispatchers.Default) {
        val pm = context.packageManager
        val own = context.packageName
        val found = LinkedHashMap<String, InstalledApp>()
        for (category in listOf(Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER)) {
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(category)
            val resolved: List<ResolveInfo> = pm.queryIntentActivities(intent, 0)
            for (info in resolved) {
                val pkg = info.activityInfo.packageName
                if (pkg == own || found.containsKey(pkg)) continue
                found[pkg] = InstalledApp(
                    label = info.loadLabel(pm).toString(),
                    packageName = pkg,
                    activityClassName = info.activityInfo.name
                )
            }
        }
        found.values.sortedBy { it.label.lowercase() }
    }

    fun buildLaunchIntent(packageName: String, activityClassName: String?): Intent? {
        return if (activityClassName != null) {
            Intent().apply {
                setClassName(packageName, activityClassName)
                addCategory(Intent.CATEGORY_LAUNCHER)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            null
        }
    }
}
