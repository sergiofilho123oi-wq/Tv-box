package com.tvboxos.launcher.util

/**
 * Conjunto fixo de avatares simples (emoji) para a Etapa 1.
 *
 * Escolher foto da galeria via Storage Access Framework está planejado,
 * mas NÃO implementado ainda — ver CONTINUAR_PROJETO.md, seção
 * "Funcionalidades parcialmente implementadas".
 */
object AvatarProvider {
    val options = listOf("😀", "🙂", "😎", "🧑", "👩", "👨", "🧔", "👵", "👴", "🐱", "🐶", "🚀")

    fun initialOf(name: String): String =
        name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
}
