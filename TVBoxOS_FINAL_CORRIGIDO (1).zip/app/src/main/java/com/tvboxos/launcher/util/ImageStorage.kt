package com.tvboxos.launcher.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.LruCache
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Copia imagens escolhidas pelo Storage Access Framework para o armazenamento
 * PRIVADO do app (filesDir/profiles/<id>/), já reduzidas. Assim:
 *  - não dependemos de permissão persistente da URI original;
 *  - cada perfil tem seus próprios arquivos (isolamento real);
 *  - o papel de parede nunca passa de 1920x1080 (cabe na RAM/GPU da TV box).
 */
object ImageStorage {

    const val WALLPAPER_MAX_W = 1920
    const val WALLPAPER_MAX_H = 1080
    const val AVATAR_SIZE = 256

    private val avatarCache = object : LruCache<String, Bitmap>(16) {}

    fun profileDir(context: Context, profileId: Long): File =
        File(context.filesDir, "profiles/$profileId").also { it.mkdirs() }

    /** Salva o papel de parede. Devolve o caminho do arquivo ou null se a imagem for ilegível. */
    suspend fun saveWallpaper(context: Context, profileId: Long, uri: Uri): String? =
        withContext(Dispatchers.IO) {
            val bmp = decode(context, uri, WALLPAPER_MAX_W, WALLPAPER_MAX_H, Bitmap.Config.RGB_565)
                ?: return@withContext null
            val (w, h) = ImageMath.fitWithin(bmp.width, bmp.height, WALLPAPER_MAX_W, WALLPAPER_MAX_H)
            val scaled = if (w != bmp.width || h != bmp.height) Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
            val out = File(profileDir(context, profileId), "wallpaper_${System.currentTimeMillis()}.jpg")
            writeJpeg(scaled, out, 88)
            if (scaled !== bmp) bmp.recycle()
            scaled.recycle()
            out.absolutePath
        }

    /** Salva o avatar recortado em quadrado 256x256. */
    suspend fun saveAvatar(context: Context, profileId: Long, uri: Uri): String? =
        withContext(Dispatchers.IO) {
            val bmp = decode(context, uri, AVATAR_SIZE * 2, AVATAR_SIZE * 2, Bitmap.Config.ARGB_8888)
                ?: return@withContext null
            val (x, y, side) = ImageMath.centerSquare(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, x, y, side, side)
            val scaledAvatar = Bitmap.createScaledBitmap(square, AVATAR_SIZE, AVATAR_SIZE, true)
            val out = File(profileDir(context, profileId), "avatar_${System.currentTimeMillis()}.jpg")
            writeJpeg(scaledAvatar, out, 90)
            listOf(bmp, square, scaledAvatar).distinct().forEach { if (!it.isRecycled) it.recycle() }
            out.absolutePath
        }

    /** Decodifica reduzindo (inSampleSize) e corrigindo a rotação EXIF. Retorna null se falhar. */
    fun decode(context: Context, uri: Uri, reqW: Int, reqH: Int, config: Bitmap.Config): Bitmap? {
        return try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val opts = BitmapFactory.Options().apply {
                inSampleSize = ImageMath.inSampleSize(bounds.outWidth, bounds.outHeight, reqW, reqH)
                inPreferredConfig = config
            }
            val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null

            val degrees = resolver.openInputStream(uri)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
            if (degrees == 0f) raw else {
                val m = Matrix().apply { postRotate(degrees) }
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true).also { if (it !== raw) raw.recycle() }
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** Carrega um arquivo já salvo (papel de parede) em RGB_565 para poupar memória. */
    fun loadWallpaper(path: String?): Bitmap? {
        if (path.isNullOrEmpty() || !File(path).exists()) return null
        return try {
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 })
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** Avatar pequeno (256 px) com cache em memória. */
    fun loadAvatar(path: String?): Bitmap? {
        if (path.isNullOrEmpty()) return null
        avatarCache.get(path)?.let { return it }
        if (!File(path).exists()) return null
        val bmp = BitmapFactory.decodeFile(path) ?: return null
        avatarCache.put(path, bmp)
        return bmp
    }

    fun deleteQuietly(path: String?) {
        if (path.isNullOrEmpty()) return
        avatarCache.remove(path)
        try { File(path).delete() } catch (_: Exception) {}
    }

    fun deleteProfileDir(context: Context, profileId: Long) {
        try { File(context.filesDir, "profiles/$profileId").deleteRecursively() } catch (_: Exception) {}
    }

    private fun writeJpeg(bmp: Bitmap, file: File, quality: Int) {
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }
}
