package com.tvboxos.launcher.util

import java.text.Normalizer
import java.util.Locale

/**
 * Normalização para busca: ignora maiúsculas/minúsculas e acentos
 * ("camera" encontra "Câmera"). Lógica pura, sem dependência do Android.
 */
object SearchNormalizer {
    private val DIACRITICS = Regex("\\p{InCombiningDiacriticalMarks}+")

    fun normalize(text: String): String =
        Normalizer.normalize(text.trim(), Normalizer.Form.NFD)
            .replace(DIACRITICS, "")
            .lowercase(Locale.ROOT)

    /** Filtra qualquer lista pelo rótulo. Consulta vazia devolve a lista inteira. */
    fun <T> filter(items: List<T>, query: String, labelOf: (T) -> String): List<T> {
        val q = normalize(query)
        if (q.isEmpty()) return items
        val starts = ArrayList<T>()
        val contains = ArrayList<T>()
        for (item in items) {
            val label = normalize(labelOf(item))
            when {
                label.startsWith(q) -> starts.add(item)
                label.contains(q) -> contains.add(item)
            }
        }
        // Quem começa com o texto vem antes de quem apenas contém.
        return starts + contains
    }
}
