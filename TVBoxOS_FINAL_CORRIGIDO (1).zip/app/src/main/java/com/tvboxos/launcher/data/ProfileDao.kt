package com.tvboxos.launcher.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {

    @Query("SELECT * FROM profiles ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<Profile>>

    @Query("SELECT * FROM profiles ORDER BY createdAt ASC")
    suspend fun getAll(): List<Profile>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Profile?

    @Insert
    suspend fun insert(profile: Profile): Long

    @Update
    suspend fun update(profile: Profile)

    @Delete
    suspend fun delete(profile: Profile)

    // Atualizações pontuais: não sobrescrevem outras colunas com uma cópia desatualizada do perfil.
    @Query("UPDATE profiles SET wallpaperPath = :path WHERE id = :id")
    suspend fun setWallpaperPath(id: Long, path: String?)

    @Query("UPDATE profiles SET avatarImagePath = :path WHERE id = :id")
    suspend fun setAvatarImagePath(id: Long, path: String?)

    @Query("SELECT COUNT(*) FROM profiles")
    suspend fun count(): Int
}
