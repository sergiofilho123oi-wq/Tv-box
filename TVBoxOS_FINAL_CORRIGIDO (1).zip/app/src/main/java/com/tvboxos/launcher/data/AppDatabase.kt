package com.tvboxos.launcher.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Profile::class, DesktopIconEntity::class],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun profileDao(): ProfileDao
    abstract fun desktopIconDao(): DesktopIconDao

    companion object {
        /** SQL da migração 1→2 (Etapa 2): foto de avatar. Exposto para teste instrumentado. */
        const val MIGRATION_1_2_SQL = "ALTER TABLE profiles ADD COLUMN avatarImagePath TEXT"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(MIGRATION_1_2_SQL)
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tvboxos.db"
                )
                    // Sem fallbackToDestructiveMigration: perfis e senhas nunca devem ser apagados
                    // por uma atualização. Toda mudança de schema precisa de uma Migration.
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

class Converters {
    @TypeConverter
    fun fromIconType(type: IconType): String = type.name

    @TypeConverter
    fun toIconType(value: String): IconType = IconType.valueOf(value)
}
