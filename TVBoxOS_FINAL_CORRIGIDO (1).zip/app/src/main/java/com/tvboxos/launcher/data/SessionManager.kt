package com.tvboxos.launcher.data

import android.content.Context

/**
 * Guarda qual perfil está autenticado no momento, sobrevivendo a reinícios do app
 * (ex.: TV box desligada e ligada de novo) até que o usuário escolha "Bloquear sessão"
 * ou "Trocar usuário".
 *
 * Usa SharedPreferences (simples e robusto para um único valor), conforme permitido
 * no item 14 do briefing ("SharedPreferences ou DataStore").
 */
class SessionManager(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("tvboxos_session", Context.MODE_PRIVATE)

    var currentProfileId: Long
        get() = prefs.getLong(KEY_PROFILE_ID, NO_PROFILE)
        set(value) = prefs.edit().putLong(KEY_PROFILE_ID, value).apply()

    val isLoggedIn: Boolean
        get() = currentProfileId != NO_PROFILE

    fun clearSession() {
        prefs.edit().remove(KEY_PROFILE_ID).apply()
    }

    companion object {
        private const val KEY_PROFILE_ID = "current_profile_id"
        const val NO_PROFILE = -1L
    }
}
