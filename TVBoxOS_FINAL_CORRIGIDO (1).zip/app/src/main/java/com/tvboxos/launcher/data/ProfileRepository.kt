package com.tvboxos.launcher.data

import android.content.Context
import android.net.Uri
import com.tvboxos.launcher.util.ImageStorage
import com.tvboxos.launcher.util.PasswordUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Único ponto de acesso aos dados de perfis e ícones de desktop.
 * Mantém a lógica de negócio (ex.: verificação de senha) fora das Activities.
 */
class ProfileRepository(context: Context) {

    private val appContext = context.applicationContext

    private val db = AppDatabase.getInstance(context)
    private val profileDao = db.profileDao()
    private val iconDao = db.desktopIconDao()

    fun observeProfiles(): Flow<List<Profile>> = profileDao.observeAll()

    suspend fun getAllProfiles(): List<Profile> = profileDao.getAll()

    suspend fun getProfile(id: Long): Profile? = profileDao.getById(id)

    suspend fun hasAnyProfile(): Boolean = profileDao.count() > 0

    suspend fun createProfile(name: String, avatarEmoji: String, password: String?): Long {
        val salt = if (password.isNullOrBlank()) null else PasswordUtils.generateSalt()
        val hash = if (password.isNullOrBlank()) null else PasswordUtils.hash(password, salt!!)
        val profile = Profile(
            name = name.trim(),
            avatarEmoji = avatarEmoji,
            passwordHash = hash,
            passwordSalt = salt,
            wallpaperPath = null,
            createdAt = System.currentTimeMillis()
        )
        return profileDao.insert(profile)
    }

    suspend fun updateProfileName(profile: Profile, newName: String): Profile {
        val updated = profile.copy(name = newName.trim())
        profileDao.update(updated)
        return updated
    }

    suspend fun updateProfileAvatar(profile: Profile, avatarEmoji: String): Profile {
        val updated = profile.copy(avatarEmoji = avatarEmoji)
        profileDao.update(updated)
        return updated
    }

    suspend fun updateProfilePassword(profile: Profile, newPassword: String?): Profile {
        val salt = if (newPassword.isNullOrBlank()) null else PasswordUtils.generateSalt()
        val hash = if (newPassword.isNullOrBlank()) null else PasswordUtils.hash(newPassword, salt!!)
        val updated = profile.copy(passwordHash = hash, passwordSalt = salt)
        profileDao.update(updated)
        return updated
    }

    suspend fun updateWallpaper(profile: Profile, path: String?): Profile {
        val updated = profile.copy(wallpaperPath = path)
        profileDao.update(updated)
        return updated
    }

    suspend fun deleteProfile(profile: Profile) {
        iconDao.deleteAllForProfile(profile.id)
        profileDao.delete(profile)
        // Remove também as imagens (papel de parede/avatar) do perfil.
        withContext(Dispatchers.IO) { ImageStorage.deleteProfileDir(appContext, profile.id) }
    }

    // --- Personalização (Etapa 2): imagens vindas da galeria via SAF ---

    /** Copia a imagem escolhida para o armazenamento do perfil. Devolve false se ilegível. */
    suspend fun setWallpaperFromUri(profileId: Long, uri: Uri): Boolean {
        val old = profileDao.getById(profileId)?.wallpaperPath
        val path = ImageStorage.saveWallpaper(appContext, profileId, uri) ?: return false
        profileDao.setWallpaperPath(profileId, path)
        withContext(Dispatchers.IO) { ImageStorage.deleteQuietly(old) }
        return true
    }

    suspend fun clearWallpaper(profileId: Long) {
        val old = profileDao.getById(profileId)?.wallpaperPath
        profileDao.setWallpaperPath(profileId, null)
        withContext(Dispatchers.IO) { ImageStorage.deleteQuietly(old) }
    }

    suspend fun setAvatarImageFromUri(profileId: Long, uri: Uri): Boolean {
        val old = profileDao.getById(profileId)?.avatarImagePath
        val path = ImageStorage.saveAvatar(appContext, profileId, uri) ?: return false
        profileDao.setAvatarImagePath(profileId, path)
        withContext(Dispatchers.IO) { ImageStorage.deleteQuietly(old) }
        return true
    }

    suspend fun clearAvatarImage(profileId: Long) {
        val old = profileDao.getById(profileId)?.avatarImagePath
        profileDao.setAvatarImagePath(profileId, null)
        withContext(Dispatchers.IO) { ImageStorage.deleteQuietly(old) }
    }

    fun verifyPassword(profile: Profile, attempt: String): Boolean {
        if (profile.passwordHash == null || profile.passwordSalt == null) return true
        return PasswordUtils.hash(attempt, profile.passwordSalt) == profile.passwordHash
    }

    // --- Ícones da área de trabalho (isolados por perfil) ---

    fun observeIcons(profileId: Long): Flow<List<DesktopIconEntity>> =
        iconDao.observeForProfile(profileId)

    suspend fun getIcons(profileId: Long): List<DesktopIconEntity> =
        iconDao.getForProfile(profileId)

    suspend fun addAppShortcut(profileId: Long, label: String, packageName: String, activityClassName: String?) {
        if (iconDao.existsForProfile(profileId, packageName) > 0) return // evita duplicar
        val nextPos = (iconDao.maxPosition(profileId) ?: -1) + 1
        iconDao.insert(
            DesktopIconEntity(
                profileId = profileId,
                label = label,
                packageName = packageName,
                activityClassName = activityClassName,
                position = nextPos,
                type = IconType.APP
            )
        )
    }

    suspend fun createFolder(profileId: Long, label: String) {
        val nextPos = (iconDao.maxPosition(profileId) ?: -1) + 1
        iconDao.insert(
            DesktopIconEntity(
                profileId = profileId,
                label = label,
                packageName = "",
                activityClassName = null,
                position = nextPos,
                type = IconType.FOLDER
            )
        )
    }

    suspend fun renameIcon(icon: DesktopIconEntity, newLabel: String) {
        iconDao.update(icon.copy(label = newLabel))
    }

    suspend fun removeIcon(icon: DesktopIconEntity) {
        iconDao.delete(icon)
    }

    suspend fun saveIconOrder(icons: List<DesktopIconEntity>) {
        iconDao.updateAll(icons)
    }

    /** Persiste a nova ordem (renumera `position` 0..n-1) e devolve a lista gravada. */
    suspend fun reorderIcons(ordered: List<DesktopIconEntity>): List<DesktopIconEntity> {
        val renumbered = com.tvboxos.launcher.util.IconOrder.renumber(ordered)
        iconDao.updateAll(renumbered)
        return renumbered
    }
}
