package com.tvboxos.launcher.desktop

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job

/** Lista de apps instalados (Menu Iniciar e diálogo "Adicionar aplicativo"). */
class AppListAdapter(
    private val scope: CoroutineScope,
    private val onClick: (InstalledApp) -> Unit,
    private val onMenu: ((InstalledApp, View) -> Unit)? = null
) : RecyclerView.Adapter<AppListAdapter.VH>() {

    private var items: List<InstalledApp> = emptyList()

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.imgAppIcon)
        val name: TextView = view.findViewById(R.id.txtAppName)
        var job: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_installed_app, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.name.text = app.label
        holder.job?.cancel()
        val ctx = holder.itemView.context
        holder.job = AppIconLoader.bind(
            holder.icon, ctx.packageManager, app.packageName, app.activityClassName,
            scope, ctx.getDrawable(R.drawable.ic_default_app)
        )
        holder.itemView.setOnClickListener { onClick(app) }
        if (onMenu != null) {
            holder.itemView.setOnLongClickListener { onMenu.invoke(app, holder.itemView); true }
            holder.itemView.setOnContextClickListener { onMenu.invoke(app, holder.itemView); true }
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        holder.job = null
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<InstalledApp>) {
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].packageName == newItems[n].packageName
            override fun areContentsTheSame(o: Int, n: Int) = old[o] == newItems[n]
        })
        items = newItems
        diff.dispatchUpdatesTo(this)
    }
}
