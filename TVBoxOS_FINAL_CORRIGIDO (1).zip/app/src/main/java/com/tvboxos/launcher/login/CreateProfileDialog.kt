package com.tvboxos.launcher.login

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import com.tvboxos.launcher.util.ImageStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.R
import com.tvboxos.launcher.data.Profile
import com.tvboxos.launcher.util.AvatarProvider

/**
 * Diálogo único usado tanto para CRIAR quanto para EDITAR um perfil.
 * Se `existingProfile` for != null, os campos vêm pré-preenchidos (edição).
 */
class CreateProfileDialog(
    private val context: Context,
    private val scope: CoroutineScope,
    private val existingProfile: Profile? = null,
    /** Pede à Activity para abrir o seletor de imagens (SAF); o resultado volta em [onPhotoPicked]. */
    private val onPickPhoto: () -> Unit,
    private val onConfirm: (name: String, avatar: String, password: String?, photoUri: Uri?, removePhoto: Boolean) -> Unit
) {

    private var selectedAvatar: String = existingProfile?.avatarEmoji ?: AvatarProvider.options.first()
    private var pickedPhoto: Uri? = null
    private var removePhoto = false
    private var photoPreview: ImageView? = null
    private var removeButton: Button? = null

    /** Chamado pela Activity quando o usuário escolheu uma imagem na galeria. */
    fun onPhotoPicked(uri: Uri) {
        pickedPhoto = uri
        removePhoto = false
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                ImageStorage.decode(context, uri, 128, 128, Bitmap.Config.ARGB_8888)
            }
            if (bmp != null) showPreview(bmp) else {
                pickedPhoto = null
                Toast.makeText(context, R.string.personalize_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showPreview(bmp: Bitmap?) {
        photoPreview?.apply {
            setImageBitmap(bmp)
            visibility = if (bmp != null) View.VISIBLE else View.GONE
        }
        removeButton?.visibility = if (bmp != null) View.VISIBLE else View.GONE
    }

    fun show() {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_create_profile, null)
        val editName = view.findViewById<EditText>(R.id.editName)
        val editPassword = view.findViewById<EditText>(R.id.editPassword)
        val recyclerAvatars = view.findViewById<RecyclerView>(R.id.recyclerAvatars)

        editName.setText(existingProfile?.name ?: "")
        // Por segurança, nunca pré-preenchemos o campo de senha com o hash existente.
        editPassword.hint = if (existingProfile?.passwordHash != null)
            context.getString(R.string.login_profile_password_optional) + " (mantenha vazio para não alterar)"
        else
            context.getString(R.string.login_profile_password_optional)

        photoPreview = view.findViewById(R.id.imgProfilePhotoPreview)
        removeButton = view.findViewById(R.id.btnRemovePhoto)
        view.findViewById<Button>(R.id.btnChoosePhoto).setOnClickListener { onPickPhoto() }
        removeButton?.setOnClickListener {
            pickedPhoto = null
            removePhoto = true
            showPreview(null)
        }
        // Edição: mostra a foto atual, se houver.
        ImageStorage.loadAvatar(existingProfile?.avatarImagePath)?.let { showPreview(it) }

        recyclerAvatars.layoutManager = GridLayoutManager(context, 6)
        recyclerAvatars.adapter = AvatarAdapter(AvatarProvider.options, selectedAvatar) { chosen ->
            selectedAvatar = chosen
        }

        val title = if (existingProfile == null)
            context.getString(R.string.login_create_profile)
        else
            context.getString(R.string.login_edit_profile)

        AlertDialog.Builder(context)
            .setTitle(title)
            .setView(view)
            .setPositiveButton(R.string.login_save) { _, _ ->
                val name = editName.text.toString().trim()
                if (name.isEmpty()) {
                    // Em uma iteração futura, mostrar erro inline em vez de ignorar.
                    return@setPositiveButton
                }
                val password = editPassword.text.toString().ifBlank { null }
                onConfirm(name, selectedAvatar, password, pickedPhoto, removePhoto)
            }
            .setNegativeButton(R.string.login_cancel, null)
            .show()
    }

    private class AvatarAdapter(
        private val options: List<String>,
        private var selected: String,
        private val onSelect: (String) -> Unit
    ) : RecyclerView.Adapter<AvatarAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val txt: TextView = view.findViewById(R.id.txtAvatarOption)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_avatar_option, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val emoji = options[position]
            holder.txt.text = emoji
            holder.txt.alpha = if (emoji == selected) 1f else 0.5f
            holder.txt.setOnClickListener {
                selected = emoji
                onSelect(emoji)
                notifyDataSetChanged()
            }
        }

        override fun getItemCount(): Int = options.size
    }
}
