package com.tvboxos.launcher.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DesktopIconDao {

    @Query("SELECT * FROM desktop_icons WHERE profileId = :profileId ORDER BY position ASC")
    fun observeForProfile(profileId: Long): Flow<List<DesktopIconEntity>>

    @Query("SELECT * FROM desktop_icons WHERE profileId = :profileId ORDER BY position ASC")
    suspend fun getForProfile(profileId: Long): List<DesktopIconEntity>

    @Query("SELECT COUNT(*) FROM desktop_icons WHERE profileId = :profileId AND packageName = :pkg")
    suspend fun existsForProfile(profileId: Long, pkg: String): Int

    @Insert
    suspend fun insert(icon: DesktopIconEntity): Long

    @Update
    suspend fun update(icon: DesktopIconEntity)

    @Update
    suspend fun updateAll(icons: List<DesktopIconEntity>)

    @Delete
    suspend fun delete(icon: DesktopIconEntity)

    @Query("DELETE FROM desktop_icons WHERE profileId = :profileId")
    suspend fun deleteAllForProfile(profileId: Long)

    @Query("SELECT MAX(position) FROM desktop_icons WHERE profileId = :profileId")
    suspend fun maxPosition(profileId: Long): Int?
}
