package com.tvboxos.launcher.login

import android.content.Context
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.tvboxos.launcher.R

class PasswordPromptDialog(
    private val context: Context,
    private val onCorrect: () -> Unit,
    private val checkPassword: (String) -> Boolean
) {
    fun show() {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_password_prompt, null)
        val editPassword = view.findViewById<EditText>(R.id.editPassword)
        val txtError = view.findViewById<TextView>(R.id.txtError)

        val dialog = AlertDialog.Builder(context)
            .setTitle(R.string.login_enter_password)
            .setView(view)
            .setPositiveButton(R.string.login_enter, null) // tratado manualmente abaixo
            .setNegativeButton(R.string.login_cancel, null)
            .create()

        dialog.setOnShowListener {
            val btn = dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
            btn.setOnClickListener {
                val attempt = editPassword.text.toString()
                if (checkPassword(attempt)) {
                    dialog.dismiss()
                    onCorrect()
                } else {
                    txtError.visibility = android.view.View.VISIBLE
                }
            }
        }

        dialog.show()
    }
}
