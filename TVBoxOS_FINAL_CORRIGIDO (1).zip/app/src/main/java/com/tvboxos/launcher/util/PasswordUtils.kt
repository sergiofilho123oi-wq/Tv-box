package com.tvboxos.launcher.util

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * A senha do perfil NUNCA é armazenada em texto puro.
 * Guardamos apenas hash(SHA-256) + salt aleatório, no banco Room local.
 *
 * Observação honesta sobre limites de segurança:
 * Isso protege contra alguém que apenas abra o app e tente perfis.
 * Não é uma criptografia de disco completa: alguém com acesso root ao
 * aparelho, ou que extraia o banco de dados, poderia tentar quebrar o hash
 * por força bruta. Para o caso de uso (TV box doméstica compartilhada),
 * esse nível de proteção é adequado e condizente com o que o Android permite
 * a um app comum (sem privilégios de sistema).
 */
object PasswordUtils {

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hash(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt.toByteArray())
        val hashed = digest.digest(password.toByteArray())
        return hashed.joinToString("") { "%02x".format(it) }
    }
}
