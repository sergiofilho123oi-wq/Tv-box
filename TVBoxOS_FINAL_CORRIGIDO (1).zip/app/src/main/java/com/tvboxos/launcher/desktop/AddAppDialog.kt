package com.tvboxos.launcher.desktop

import android.content.Context
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Diálogo "Adicionar aplicativo". A lista é carregada em coroutine (não trava a UI). */
class AddAppDialog(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onAppChosen: (InstalledApp) -> Unit
) {
    fun show() {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_add_app, null)
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerInstalledApps)
        recycler.layoutManager = LinearLayoutManager(context)

        val dialog = AlertDialog.Builder(context)
            .setTitle(R.string.desktop_add_app)
            .setView(view)
            .setNegativeButton(R.string.login_cancel, null)
            .create()

        val adapter = AppListAdapter(scope, onClick = { app ->
            onAppChosen(app)
            dialog.dismiss()
        })
        recycler.adapter = adapter
        dialog.show()

        scope.launch { adapter.submit(InstalledAppsProvider.list(context)) }
    }
}
