package com.tvboxos.launcher

import android.app.Application
import com.tvboxos.launcher.data.ProfileRepository
import com.tvboxos.launcher.data.SessionManager

class App : Application() {

    lateinit var repository: ProfileRepository
        private set

    lateinit var session: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()
        repository = ProfileRepository(this)
        session = SessionManager(this)
    }
}
