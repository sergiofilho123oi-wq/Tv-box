package com.tvboxos.launcher.util

import com.tvboxos.launcher.data.DesktopIconEntity

/** Regras puras de ordenação dos ícones da área de trabalho (campo `position`). */
object IconOrder {

    /** Move o item de [from] para [to]; índices inválidos devolvem a lista inalterada. */
    fun move(list: List<DesktopIconEntity>, from: Int, to: Int): List<DesktopIconEntity> {
        if (from !in list.indices || to !in list.indices || from == to) return list
        val mutable = list.toMutableList()
        val item = mutable.removeAt(from)
        mutable.add(to, item)
        return mutable
    }

    /** Reescreve `position` como 0..n-1 seguindo a ordem atual da lista. */
    fun renumber(list: List<DesktopIconEntity>): List<DesktopIconEntity> =
        list.mapIndexed { index, icon -> if (icon.position == index) icon else icon.copy(position = index) }
}
