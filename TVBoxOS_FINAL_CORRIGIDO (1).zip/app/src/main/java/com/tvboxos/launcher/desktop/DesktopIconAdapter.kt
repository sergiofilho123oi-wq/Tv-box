package com.tvboxos.launcher.desktop

import android.graphics.Color
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.R
import com.tvboxos.launcher.data.DesktopIconEntity
import com.tvboxos.launcher.data.IconType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job

/** Compara duas listas de ícones para o DiffUtil (item = mesmo id; conteúdo = data class igual). */
class DesktopIconDiffCallback(
    private val old: List<DesktopIconEntity>,
    private val new: List<DesktopIconEntity>
) : DiffUtil.Callback() {
    override fun getOldListSize() = old.size
    override fun getNewListSize() = new.size
    override fun areItemsTheSame(o: Int, n: Int) = old[o].id == new[n].id
    override fun areContentsTheSame(o: Int, n: Int) = old[o] == new[n]
}

class DesktopIconAdapter(
    private val scope: CoroutineScope,
    private val onClick: (DesktopIconEntity) -> Unit,
    private val onMenu: (DesktopIconEntity, View) -> Unit
) : RecyclerView.Adapter<DesktopIconAdapter.VH>() {

    private var icons: MutableList<DesktopIconEntity> = ArrayList()
    private var onWallpaper = false

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.imgIcon)
        val label: TextView = view.findViewById(R.id.txtLabel)
        var job: Job? = null
    }

    val currentList: List<DesktopIconEntity> get() = icons

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_desktop_icon, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val icon = icons[position]
        holder.label.text = icon.label
        // Com foto de fundo, o texto fica branco com sombra para continuar legível.
        if (onWallpaper) {
            holder.label.setTextColor(Color.WHITE)
            holder.label.setShadowLayer(4f, 0f, 1f, Color.BLACK)
        } else {
            holder.label.setTextColor(holder.itemView.context.getColor(R.color.tvbox_text_primary_light))
            holder.label.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        }

        holder.job?.cancel()
        holder.job = null
        val ctx = holder.itemView.context
        when (icon.type) {
            IconType.FOLDER -> holder.img.setImageResource(R.drawable.ic_folder)
            IconType.DOCUMENT -> holder.img.setImageResource(R.drawable.ic_default_app)
            IconType.APP -> holder.job = AppIconLoader.bind(
                holder.img, ctx.packageManager, icon.packageName, icon.activityClassName,
                scope, ctx.getDrawable(R.drawable.ic_default_app)
            )
        }

        holder.itemView.setOnClickListener { onClick(icon) }
        // O toque longo agora inicia o arrastar (ItemTouchHelper); o menu abre no
        // clique direito do mouse, na tecla MENU do controle ou ao soltar sem arrastar.
        holder.itemView.setOnContextClickListener { onMenu(icon, holder.itemView); true }
        holder.itemView.setOnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_MENU && event.action == KeyEvent.ACTION_UP) {
                onMenu(icon, v); true
            } else false
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        holder.job = null
    }

    override fun getItemCount(): Int = icons.size

    /** Atualiza a lista com DiffUtil: só os itens que mudaram são redesenhados. */
    fun submitList(newIcons: List<DesktopIconEntity>) {
        val diff = DiffUtil.calculateDiff(DesktopIconDiffCallback(icons, newIcons))
        icons = ArrayList(newIcons)
        diff.dispatchUpdatesTo(this)
    }

    /** Move durante o arrastar (animação imediata). */
    fun moveItem(from: Int, to: Int) {
        if (from !in icons.indices || to !in icons.indices) return
        val item = icons.removeAt(from)
        icons.add(to, item)
        notifyItemMoved(from, to)
    }

    /** Troca a lista interna sem animar (as views já estão na posição certa após o arrastar). */
    fun commitOrder(ordered: List<DesktopIconEntity>) {
        icons = ArrayList(ordered)
    }

    fun setOnWallpaper(value: Boolean) {
        if (onWallpaper != value) {
            onWallpaper = value
            notifyItemRangeChanged(0, icons.size)
        }
    }
}
