package com.tvboxos.launcher.desktop

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.util.LruCache
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Carrega ícones de apps fora da thread principal, com cache pequeno (poupa RAM). */
object AppIconLoader {

    private val cache = object : LruCache<String, Drawable>(64) {}

    fun bind(
        view: ImageView,
        pm: PackageManager,
        packageName: String,
        activityClassName: String?,
        scope: CoroutineScope,
        fallback: Drawable?
    ): Job? {
        view.tag = packageName
        val cached = cache.get(packageName)
        if (cached != null) {
            view.setImageDrawable(cached.constantState?.newDrawable()?.mutate() ?: cached)
            return null
        }
        view.setImageDrawable(fallback)
        return scope.launch {
            val icon = withContext(Dispatchers.IO) {
                try {
                    if (activityClassName != null)
                        pm.getActivityIcon(ComponentName(packageName, activityClassName))
                    else pm.getApplicationIcon(packageName)
                } catch (e: Exception) {
                    null // app desinstalado: mantém o ícone genérico
                }
            }
            if (icon != null) {
                cache.put(packageName, icon)
                if (view.tag == packageName) {
                    view.setImageDrawable(icon.constantState?.newDrawable()?.mutate() ?: icon)
                }
            }
        }
    }

    fun clear() = cache.evictAll()
}
