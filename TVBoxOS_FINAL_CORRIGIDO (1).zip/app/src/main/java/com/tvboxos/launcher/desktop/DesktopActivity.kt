package com.tvboxos.launcher.desktop

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.tvboxos.launcher.util.AvatarView
import com.tvboxos.launcher.util.IconOrder
import com.tvboxos.launcher.util.ImageStorage
import com.tvboxos.launcher.util.SearchNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.App
import com.tvboxos.launcher.R
import com.tvboxos.launcher.data.DesktopIconEntity
import com.tvboxos.launcher.data.Profile
import com.tvboxos.launcher.login.LoginActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Área de trabalho de UM perfil (o perfil atualmente em sessão, via SessionManager).
 * Mostra: grade de ícones daquele perfil, barra de tarefas com menu Iniciar,
 * relógio e status de Wi-Fi. Itens 4, 9, 10 do briefing.
 */
class DesktopActivity : AppCompatActivity() {

    private val app: App by lazy { application as App }
    private lateinit var currentProfile: Profile

    private lateinit var recyclerIcons: RecyclerView
    private lateinit var iconAdapter: DesktopIconAdapter
    private lateinit var txtClock: TextView
    private lateinit var imgWifi: ImageView

    private var iconsJob: Job? = null
    private var allApps: List<InstalledApp> = emptyList()
    private var personalizeDialog: PersonalizeDialog? = null
    private var currentWallpaper: Bitmap? = null

    private lateinit var startOverlay: View
    private lateinit var editSearch: EditText
    private lateinit var startAdapter: AppListAdapter

    private val pickWallpaper = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setWallpaperFrom(uri)
    }
    private val pickAvatar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setAvatarFrom(uri)
    }

    /** Atualiza a lista do Menu Iniciar quando um app é instalado/removido. */
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeStartMenu()
    }

    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClockAndWifi()
            clockHandler.postDelayed(this, 15_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_desktop)

        val profileId = app.session.currentProfileId
        if (profileId == com.tvboxos.launcher.data.SessionManager.NO_PROFILE) {
            // Sem sessão válida: volta para o login em vez de quebrar a tela.
            goToLogin()
            return
        }

        recyclerIcons = findViewById(R.id.recyclerDesktopIcons)
        recyclerIcons.layoutManager = GridLayoutManager(this, 6)

        iconAdapter = DesktopIconAdapter(
            scope = lifecycleScope,
            onClick = { icon -> openIcon(icon) },
            onMenu = { icon, anchor -> showIconMenu(icon, anchor) }
        )
        recyclerIcons.adapter = iconAdapter

        // Arrastar e reordenar (toque longo/mouse pressionado); grava em `position` ao soltar.
        ItemTouchHelper(
            IconDragCallback(
                adapter = iconAdapter,
                onDropped = { persistIconOrder() },
                onHoldWithoutMove = { pos, view ->
                    iconAdapter.currentList.getOrNull(pos)?.let { showIconMenu(it, view) }
                }
            )
        ).attachToRecyclerView(recyclerIcons)

        setupStartMenu()
        onBackPressedDispatcher.addCallback(this, backCallback)

        // Menu de contexto da área VAZIA da área de trabalho (item 5 do briefing)
        registerForContextMenu(recyclerIcons)

        txtClock = findViewById(R.id.txtTaskbarClock)
        imgWifi = findViewById(R.id.imgWifiStatus)

        findViewById<View>(R.id.btnStart).setOnClickListener { toggleStartMenu() }

        lifecycleScope.launch {
            val profile = app.repository.getProfile(profileId)
            if (profile == null) {
                goToLogin()
                return@launch
            }
            currentProfile = profile
            applyWallpaper(profile)
            bindStartUser(profile)
            observeIcons(profile.id)
        }
    }

    private fun observeIcons(profileId: Long) {
        iconsJob?.cancel() // evita coletores duplicados (ex.: "Atualizar")
        iconsJob = lifecycleScope.launch {
            app.repository.observeIcons(profileId).collect { icons ->
                iconAdapter.submitList(icons)
            }
        }
    }

    /** Lê a imagem do disco fora da thread principal e a aplica; sem imagem, volta à cor padrão. */
    private fun applyWallpaper(profile: Profile) {
        val img = findViewById<ImageView>(R.id.imgWallpaper)
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { ImageStorage.loadWallpaper(profile.wallpaperPath) }
            // Sem recycle() manual: o diálogo de personalização pode estar exibindo o mesmo
            // bitmap, e reciclar causaria crash. O GC libera o antigo (RGB_565, ~4 MB).
            currentWallpaper = bmp
            if (bmp != null) {
                img.setImageBitmap(bmp)
                img.visibility = View.VISIBLE
            } else {
                img.setImageDrawable(null)
                img.visibility = View.GONE
            }
            iconAdapter.setOnWallpaper(bmp != null)
            personalizeDialog?.takeIf { it.isShowing }?.refresh(profile, bmp)
        }
    }

    // ---------------- Personalização (SAF) ----------------

    private fun showPersonalize() {
        closeStartMenu()
        val dialog = PersonalizeDialog(
            context = this,
            onChooseWallpaper = { launchPicker(pickWallpaper) },
            onResetWallpaper = {
                lifecycleScope.launch {
                    app.repository.clearWallpaper(currentProfile.id)
                    reloadProfile()
                }
            },
            onChooseAvatar = { launchPicker(pickAvatar) },
            onRemoveAvatar = {
                lifecycleScope.launch {
                    app.repository.clearAvatarImage(currentProfile.id)
                    reloadProfile()
                }
            }
        )
        personalizeDialog = dialog
        dialog.show(currentProfile)
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { ImageStorage.loadWallpaper(currentProfile.wallpaperPath) }
            dialog.refresh(currentProfile, bmp)
        }
    }

    private fun launchPicker(launcher: androidx.activity.result.ActivityResultLauncher<Array<String>>) {
        try {
            launcher.launch(arrayOf("image/*"))
        } catch (e: ActivityNotFoundException) {
            // Algumas TV boxes não trazem o seletor de arquivos (DocumentsUI).
            Toast.makeText(this, R.string.picker_unavailable, Toast.LENGTH_LONG).show()
        }
    }

    private fun setWallpaperFrom(uri: Uri) {
        lifecycleScope.launch {
            val ok = app.repository.setWallpaperFromUri(currentProfile.id, uri)
            Toast.makeText(this@DesktopActivity, if (ok) R.string.personalize_saved else R.string.personalize_failed, Toast.LENGTH_SHORT).show()
            if (ok) reloadProfile()
        }
    }

    private fun setAvatarFrom(uri: Uri) {
        lifecycleScope.launch {
            val ok = app.repository.setAvatarImageFromUri(currentProfile.id, uri)
            Toast.makeText(this@DesktopActivity, if (ok) R.string.personalize_saved else R.string.personalize_failed, Toast.LENGTH_SHORT).show()
            if (ok) reloadProfile()
        }
    }

    private suspend fun reloadProfile() {
        app.repository.getProfile(currentProfile.id)?.let {
            currentProfile = it
            applyWallpaper(it)
            bindStartUser(it)
        }
    }

    // ---------------- Reordenar ícones ----------------

    private fun persistIconOrder() {
        val ordered = IconOrder.renumber(iconAdapter.currentList)
        iconAdapter.commitOrder(ordered) // views já estão na posição certa
        lifecycleScope.launch { app.repository.saveIconOrder(ordered) }
    }

    /** Reordenar sem mouse/toque (controle remoto): menu "Mover para trás/frente". */
    private fun moveIconBy(icon: DesktopIconEntity, delta: Int) {
        val list = iconAdapter.currentList
        val from = list.indexOfFirst { it.id == icon.id }
        val to = (from + delta).coerceIn(0, list.size - 1)
        if (from < 0 || from == to) return
        iconAdapter.moveItem(from, to)
        persistIconOrder()
    }

    private fun openIcon(icon: DesktopIconEntity) {
        when (icon.type) {
            com.tvboxos.launcher.data.IconType.APP -> {
                val intent = InstalledAppsProvider.buildLaunchIntent(icon.packageName, icon.activityClassName)
                if (intent != null) {
                    try {
                        startActivity(intent)
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(this, "Não foi possível abrir o aplicativo", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
            com.tvboxos.launcher.data.IconType.FOLDER -> {
                // Pastas de verdade (abrir conteúdo) chegam no Explorador de Arquivos, Etapa 3.
                android.widget.Toast.makeText(this, "Pastas serão abertas pelo Explorador de Arquivos (Etapa 3)", android.widget.Toast.LENGTH_SHORT).show()
            }
            com.tvboxos.launcher.data.IconType.DOCUMENT -> {
                android.widget.Toast.makeText(this, "Editor de documentos chega na Etapa 3", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showIconMenu(icon: DesktopIconEntity, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_desktop_icon, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_open -> { openIcon(icon); true }
                R.id.menu_move_back -> { moveIconBy(icon, -1); true }
                R.id.menu_move_forward -> { moveIconBy(icon, +1); true }
                R.id.menu_rename -> { renameIconDialog(icon); true }
                R.id.menu_remove -> {
                    lifecycleScope.launch { app.repository.removeIcon(icon) }
                    true
                }
                R.id.menu_properties -> { showProperties(icon); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun renameIconDialog(icon: DesktopIconEntity) {
        val input = android.widget.EditText(this)
        input.setText(icon.label)
        AlertDialog.Builder(this)
            .setTitle(R.string.desktop_rename)
            .setView(input)
            .setPositiveButton(R.string.login_save) { _, _ ->
                val newLabel = input.text.toString().trim()
                if (newLabel.isNotEmpty()) {
                    lifecycleScope.launch { app.repository.renameIcon(icon, newLabel) }
                }
            }
            .setNegativeButton(R.string.login_cancel, null)
            .show()
    }

    private fun showProperties(icon: DesktopIconEntity) {
        AlertDialog.Builder(this)
            .setTitle(R.string.desktop_properties)
            .setMessage("Nome: ${icon.label}\nPacote: ${icon.packageName}\nTipo: ${icon.type}")
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        if (v.id == R.id.recyclerDesktopIcons) {
            menuInflater.inflate(R.menu.menu_desktop_empty, menu)
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_add_app -> {
                AddAppDialog(this, lifecycleScope) { app_ ->
                    lifecycleScope.launch {
                        app.repository.addAppShortcut(
                            currentProfile.id, app_.label, app_.packageName, app_.activityClassName
                        )
                    }
                }.show()
                true
            }
            R.id.menu_new_folder -> {
                val input = android.widget.EditText(this)
                AlertDialog.Builder(this)
                    .setTitle(R.string.desktop_new_folder)
                    .setView(input)
                    .setPositiveButton(R.string.login_save) { _, _ ->
                        val name = input.text.toString().trim().ifEmpty { "Nova pasta" }
                        lifecycleScope.launch { app.repository.createFolder(currentProfile.id, name) }
                    }
                    .setNegativeButton(R.string.login_cancel, null)
                    .show()
                true
            }
            R.id.menu_refresh -> {
                observeIcons(currentProfile.id)
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    // ---------------- Menu Iniciar ----------------

    private fun setupStartMenu() {
        startOverlay = findViewById(R.id.startMenuOverlay)
        editSearch = findViewById(R.id.editStartSearch)
        val recycler = findViewById<RecyclerView>(R.id.recyclerStartApps)
        recycler.layoutManager = LinearLayoutManager(this)
        startAdapter = AppListAdapter(
            scope = lifecycleScope,
            onClick = { app_ -> launchApp(app_) },
            onMenu = { app_, anchor -> showStartAppMenu(app_, anchor) }
        )
        recycler.adapter = startAdapter

        startOverlay.setOnClickListener { closeStartMenu() } // toque fora do painel fecha
        editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) = Unit
            override fun afterTextChanged(s: Editable?) = applySearch()
        })
        findViewById<View>(R.id.btnStartPersonalize).setOnClickListener { showPersonalize() }
        findViewById<View>(R.id.btnStartSwitchUser).setOnClickListener { goToLogin() }
        findViewById<View>(R.id.btnStartLock).setOnClickListener {
            app.session.clearSession()
            goToLogin()
        }
    }

    private fun bindStartUser(profile: Profile) {
        AvatarView.bind(
            profile,
            findViewById<TextView>(R.id.txtStartAvatar),
            findViewById<ImageView>(R.id.imgStartAvatar)
        )
        findViewById<TextView>(R.id.txtStartUserName).text = profile.name
    }

    private fun toggleStartMenu() {
        if (startOverlay.visibility == View.VISIBLE) closeStartMenu() else openStartMenu()
    }

    private fun openStartMenu() {
        editSearch.setText("")
        startOverlay.visibility = View.VISIBLE
        backCallback.isEnabled = true
        if (allApps.isEmpty()) loadApps() else applySearch()
        startOverlay.post { findViewById<View>(R.id.startMenuCard).requestFocus() }
    }

    private fun closeStartMenu() {
        if (startOverlay.visibility != View.VISIBLE) return
        startOverlay.visibility = View.GONE
        backCallback.isEnabled = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(editSearch.windowToken, 0)
    }

    /** Carrega os apps em coroutine (Dispatchers.Default dentro do provider). */
    private fun loadApps() {
        lifecycleScope.launch {
            allApps = InstalledAppsProvider.list(this@DesktopActivity)
            applySearch()
        }
    }

    private fun applySearch() {
        val query = editSearch.text.toString()
        val result = SearchNormalizer.filter(allApps, query) { it.label }
        startAdapter.submit(result)
        findViewById<TextView>(R.id.txtStartListTitle).setText(
            if (query.isBlank()) R.string.start_all_apps else R.string.start_results
        )
        findViewById<View>(R.id.txtStartEmpty).visibility =
            if (result.isEmpty() && allApps.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun launchApp(app_: InstalledApp) {
        val intent = InstalledAppsProvider.buildLaunchIntent(app_.packageName, app_.activityClassName)
        try {
            if (intent == null) throw IllegalStateException()
            startActivity(intent)
            closeStartMenu()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.start_open_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showStartAppMenu(app_: InstalledApp, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.desktop_open)
        popup.menu.add(0, 2, 1, R.string.start_pin_to_desktop)
        popup.menu.add(0, 3, 2, R.string.start_app_info)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { launchApp(app_); true }
                2 -> {
                    lifecycleScope.launch {
                        val already = app.repository.getIcons(currentProfile.id)
                            .any { it.packageName == app_.packageName }
                        app.repository.addAppShortcut(
                            currentProfile.id, app_.label, app_.packageName, app_.activityClassName
                        )
                        Toast.makeText(
                            this@DesktopActivity,
                            getString(if (already) R.string.start_already_pinned else R.string.start_pinned, app_.label),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    true
                }
                3 -> {
                    try {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app_.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                        Toast.makeText(this, R.string.start_open_failed, Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun goToLogin() {
        app.session.clearSession()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun updateClockAndWifi() {
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        txtClock.text = fmt.format(java.util.Date())

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val caps = connectivityManager.getNetworkCapabilities(network)
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        imgWifi.alpha = if (connected) 1.0f else 0.4f
        imgWifi.contentDescription = getString(
            if (connected) R.string.desktop_wifi_connected else R.string.desktop_wifi_disconnected
        )
    }

    override fun onStart() {
        super.onStart()
        if (!::startAdapter.isInitialized) return // saiu cedo para o login
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(packageReceiver) } catch (_: IllegalArgumentException) {}
    }

    override fun onResume() {
        super.onResume()
        clockHandler.post(clockRunnable)
    }

    override fun onPause() {
        super.onPause()
        clockHandler.removeCallbacks(clockRunnable)
    }
}
