package com.tvboxos.launcher.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Representa um perfil independente do TVBox OS (ex.: "Sérgio", "Mamãe").
 *
 * IMPORTANTE SOBRE ISOLAMENTO ENTRE PERFIS:
 * O Android não oferece, para um único app comum (sem ser o "dono" do dispositivo
 * via Android Enterprise / multi-usuário do sistema), uma forma de isolar de verdade
 * os dados de OUTROS aplicativos entre "perfis" criados dentro do próprio launcher.
 * Todos os apps instalados continuam compartilhando a mesma conta do Android.
 *
 * O que o TVBox OS PODE isolar de forma real, e isola:
 *  - Atalhos/ícones da área de trabalho de cada perfil (tabela DesktopIconEntity,
 *    filtrada por profileId).
 *  - Papel de parede e preferências de interface de cada perfil.
 *  - Documentos de texto criados pelo editor interno do TVBox OS (ficam em uma
 *    pasta própria por perfil, dentro do armazenamento do app).
 *  - A senha de acesso ao perfil (hash com salt, nunca em texto puro).
 *
 * O que o TVBox OS NÃO isola (limitação do Android, documentada para o usuário
 * na tela de exclusão/criação de perfil, ver strings.xml -> login_delete_warning):
 *  - Dados internos de outros aplicativos Android instalados no aparelho
 *    (ex.: um app de banco não terá "contas separadas" por perfil do TVBox OS).
 */
@Entity(tableName = "profiles")
data class Profile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val avatarEmoji: String, // avatar simples (emoji/inicial) para a Etapa 1
    val passwordHash: String?, // null = sem senha
    val passwordSalt: String?,
    val wallpaperPath: String?, // caminho de arquivo local; null = papel de parede padrão
    val createdAt: Long,
    // Etapa 2: foto de avatar escolhida na galeria (arquivo no armazenamento privado do app).
    // null = usa o emoji de avatarEmoji.
    val avatarImagePath: String? = null
)
