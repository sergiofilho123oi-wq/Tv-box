package com.tvboxos.launcher.login

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.R
import com.tvboxos.launcher.data.Profile

class ProfileAdapter(
    private var profiles: List<Profile>,
    private val onClick: (Profile) -> Unit,
    private val onLongClick: (Profile, View) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.ProfileViewHolder>() {

    inner class ProfileViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtAvatar: android.widget.TextView = view.findViewById(R.id.txtAvatar)
        val imgPhoto: android.widget.ImageView = view.findViewById(R.id.imgAvatarPhoto)
        val txtName: android.widget.TextView = view.findViewById(R.id.txtName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false)
        return ProfileViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
        val profile = profiles[position]
        com.tvboxos.launcher.util.AvatarView.bind(profile, holder.txtAvatar, holder.imgPhoto)
        holder.txtName.text = profile.name
        holder.itemView.setOnClickListener { onClick(profile) }
        holder.itemView.setOnLongClickListener {
            onLongClick(profile, holder.itemView)
            true
        }
        // Mouse USB: clique com o botão direito também aciona o menu de gerenciamento do perfil
        holder.itemView.setOnContextClickListener {
            onLongClick(profile, holder.itemView)
            true
        }
    }

    override fun getItemCount(): Int = profiles.size

    fun submitList(newProfiles: List<Profile>) {
        val old = profiles
        val diff = androidx.recyclerview.widget.DiffUtil.calculateDiff(object : androidx.recyclerview.widget.DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = newProfiles.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].id == newProfiles[n].id
            override fun areContentsTheSame(o: Int, n: Int) = old[o] == newProfiles[n]
        })
        profiles = newProfiles
        diff.dispatchUpdatesTo(this)
    }
}
