package com.tvboxos.launcher.util

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.tvboxos.launcher.data.Profile

/** Mostra a foto do perfil se existir; senão o emoji. Usa o par TextView + ImageView do layout. */
object AvatarView {
    fun bind(profile: Profile, emojiView: TextView, photoView: ImageView) {
        val bmp = ImageStorage.loadAvatar(profile.avatarImagePath)
        if (bmp != null) {
            photoView.setImageBitmap(bmp)
            photoView.visibility = View.VISIBLE
        } else {
            photoView.setImageDrawable(null)
            photoView.visibility = View.GONE
        }
        emojiView.text = profile.avatarEmoji
    }
}
