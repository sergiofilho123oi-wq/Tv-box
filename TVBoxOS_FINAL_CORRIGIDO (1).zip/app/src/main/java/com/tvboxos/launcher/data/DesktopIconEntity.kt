package com.tvboxos.launcher.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Um atalho/ícone na área de trabalho de um perfil específico.
 * `profileId` garante o isolamento: ícones de um perfil nunca aparecem em outro.
 *
 * `packageName` + `activityClassName` identificam o app Android a ser aberto
 * (via Intent explícita), o que é o mecanismo oficial do Android para abrir apps.
 *
 * `position` guarda a ordem/posição na grade, para a organização ser salva
 * automaticamente (requisito do item 4 do briefing).
 */
@Entity(tableName = "desktop_icons")
data class DesktopIconEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val label: String,
    val packageName: String,
    val activityClassName: String?,
    val position: Int,
    val type: IconType = IconType.APP
)

enum class IconType {
    APP,
    FOLDER,
    DOCUMENT
}
