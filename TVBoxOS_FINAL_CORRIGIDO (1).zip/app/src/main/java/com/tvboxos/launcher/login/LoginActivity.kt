package com.tvboxos.launcher.login

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvboxos.launcher.App
import com.tvboxos.launcher.R
import com.tvboxos.launcher.data.Profile
import com.tvboxos.launcher.desktop.DesktopActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Tela de seleção de usuário (item 3 do briefing).
 *
 * Fluxo:
 *  1. Se não existe nenhum perfil ainda, mostra direto a lista vazia + botão "Criar perfil".
 *  2. Usuário toca em um perfil:
 *     - sem senha -> entra direto no desktop daquele perfil.
 *     - com senha -> pede senha antes de entrar.
 *  3. Toque longo (ou clique direito do mouse) em um perfil abre menu:
 *     editar perfil, alterar senha, excluir perfil.
 */
class LoginActivity : AppCompatActivity() {

    private val app: App by lazy { application as App }
    private lateinit var recyclerProfiles: RecyclerView
    private lateinit var adapter: ProfileAdapter
    private lateinit var txtClock: TextView

    // Diálogo de perfil aberto no momento (recebe a foto escolhida na galeria)
    private var activeProfileDialog: CreateProfileDialog? = null

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { /* a permissão temporária já basta: copiamos a imagem logo em seguida */ }
            activeProfileDialog?.onPhotoPicked(uri)
        }
    }

    private fun launchPhotoPicker() {
        try {
            pickPhoto.launch(arrayOf("image/*"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.picker_unavailable, Toast.LENGTH_LONG).show()
        }
    }

    /** Aplica a foto escolhida (ou remoção) ao perfil depois de salvar nome/avatar/senha. */
    private suspend fun applyPhoto(profileId: Long, photoUri: Uri?, removePhoto: Boolean) {
        when {
            photoUri != null -> if (!app.repository.setAvatarImageFromUri(profileId, photoUri)) {
                Toast.makeText(this, R.string.personalize_failed, Toast.LENGTH_SHORT).show()
            }
            removePhoto -> app.repository.clearAvatarImage(profileId)
        }
    }

    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            clockHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        txtClock = findViewById(R.id.txtClock)
        recyclerProfiles = findViewById(R.id.recyclerProfiles)
        recyclerProfiles.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        adapter = ProfileAdapter(
            profiles = emptyList(),
            onClick = { profile -> attemptLogin(profile) },
            onLongClick = { profile, anchor -> showProfileMenu(profile, anchor) }
        )
        recyclerProfiles.adapter = adapter

        findViewById<View>(R.id.btnCreateProfile).setOnClickListener {
            showProfileDialog(null)
        }

        observeProfiles()

        // Se já existe uma sessão ativa (ex.: voltou da área de trabalho sem bloquear),
        // vai direto para o desktop daquele perfil.
        if (app.session.isLoggedIn) {
            lifecycleScope.launch {
                val profile = app.repository.getProfile(app.session.currentProfileId)
                if (profile != null) {
                    openDesktop(profile)
                }
            }
        }
    }

    private fun observeProfiles() {
        lifecycleScope.launch {
            app.repository.observeProfiles().collect { profiles ->
                adapter.submitList(profiles)
            }
        }
    }

    private fun attemptLogin(profile: Profile) {
        if (profile.passwordHash == null) {
            openDesktop(profile)
        } else {
            PasswordPromptDialog(
                context = this,
                onCorrect = { openDesktop(profile) },
                checkPassword = { attempt -> app.repository.verifyPassword(profile, attempt) }
            ).show()
        }
    }

    private fun openDesktop(profile: Profile) {
        app.session.currentProfileId = profile.id
        startActivity(Intent(this, DesktopActivity::class.java))
    }

    private fun showProfileMenu(profile: Profile, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.login_edit_profile)
        popup.menu.add(0, 2, 1, R.string.login_delete_profile)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { showProfileDialog(profile); true }
                2 -> {
                    confirmDelete(profile)
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun showProfileDialog(existing: Profile?) {
        val dialog = CreateProfileDialog(
            context = this,
            scope = lifecycleScope,
            existingProfile = existing,
            onPickPhoto = { launchPhotoPicker() }
        ) { name, avatar, password, photoUri, removePhoto ->
            lifecycleScope.launch {
                if (existing == null) {
                    val id = app.repository.createProfile(name, avatar, password)
                    applyPhoto(id, photoUri, removePhoto)
                } else {
                    var updated = app.repository.updateProfileName(existing, name)
                    updated = app.repository.updateProfileAvatar(updated, avatar)
                    if (!password.isNullOrBlank()) {
                        app.repository.updateProfilePassword(updated, password)
                    }
                    applyPhoto(existing.id, photoUri, removePhoto)
                }
            }
        }
        activeProfileDialog = dialog
        dialog.show()
    }

    private fun confirmDelete(profile: Profile) {
        AlertDialog.Builder(this)
            .setTitle(R.string.login_delete_confirm_title)
            .setMessage(getString(R.string.login_delete_confirm_message, profile.name) + "\n\n" + getString(R.string.login_delete_warning))
            .setPositiveButton(R.string.login_delete_profile) { _, _ ->
                lifecycleScope.launch {
                    app.repository.deleteProfile(profile)
                    if (app.session.currentProfileId == profile.id) {
                        app.session.clearSession()
                    }
                }
            }
            .setNegativeButton(R.string.login_cancel, null)
            .show()
    }

    private fun updateClock() {
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        txtClock.text = fmt.format(java.util.Date())
    }

    override fun onResume() {
        super.onResume()
        clockHandler.post(clockRunnable)
    }

    override fun onPause() {
        super.onPause()
        clockHandler.removeCallbacks(clockRunnable)
    }
}
