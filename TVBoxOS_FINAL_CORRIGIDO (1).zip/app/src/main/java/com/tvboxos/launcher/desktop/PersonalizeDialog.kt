package com.tvboxos.launcher.desktop

import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.tvboxos.launcher.R
import com.tvboxos.launcher.data.Profile
import com.tvboxos.launcher.util.ImageStorage

/**
 * Tela de personalização: papel de parede e foto do perfil.
 * Os botões só delegam à Activity (que abre o seletor SAF); a prévia é atualizada por [refresh].
 */
class PersonalizeDialog(
    private val context: Context,
    private val onChooseWallpaper: () -> Unit,
    private val onResetWallpaper: () -> Unit,
    private val onChooseAvatar: () -> Unit,
    private val onRemoveAvatar: () -> Unit
) {
    private var dialog: AlertDialog? = null
    private var imgWallpaper: ImageView? = null
    private var imgAvatar: ImageView? = null
    private var txtAvatar: TextView? = null

    val isShowing: Boolean get() = dialog?.isShowing == true

    fun show(profile: Profile) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_personalize, null)
        imgWallpaper = view.findViewById(R.id.imgWallpaperPreview)
        imgAvatar = view.findViewById(R.id.imgAvatarPreview)
        txtAvatar = view.findViewById(R.id.txtAvatarPreview)
        view.findViewById<Button>(R.id.btnChooseWallpaper).setOnClickListener { onChooseWallpaper() }
        view.findViewById<Button>(R.id.btnResetWallpaper).setOnClickListener { onResetWallpaper() }
        view.findViewById<Button>(R.id.btnChooseAvatarPhoto).setOnClickListener { onChooseAvatar() }
        view.findViewById<Button>(R.id.btnRemoveAvatarPhoto).setOnClickListener { onRemoveAvatar() }

        dialog = AlertDialog.Builder(context)
            .setTitle(R.string.personalize_title)
            .setView(view)
            .setPositiveButton(R.string.personalize_close, null)
            .create()
        refresh(profile, null)
        dialog?.show()
    }

    /** Atualiza as prévias. [wallpaper] já decodificado (evita ler arquivo na thread principal). */
    fun refresh(profile: Profile, wallpaper: Bitmap?) {
        imgWallpaper?.setImageBitmap(wallpaper)
        txtAvatar?.text = profile.avatarEmoji
        val avatar = ImageStorage.loadAvatar(profile.avatarImagePath)
        imgAvatar?.setImageBitmap(avatar)
        imgAvatar?.visibility = if (avatar != null) View.VISIBLE else View.GONE
    }
}
