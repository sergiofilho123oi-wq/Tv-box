package com.tvboxos.launcher

import android.view.View
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility
import androidx.test.espresso.matcher.ViewMatchers.Visibility
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tvboxos.launcher.desktop.DesktopActivity
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** UI real: abrir/fechar o Menu Iniciar e digitar na busca, com um perfil de teste em sessão. */
@RunWith(AndroidJUnit4::class)
class StartMenuTest {

    @Before fun criaPerfilEmSessao() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<App>()
        val id = app.repository.createProfile("Teste", "🙂", null)
        app.session.currentProfileId = id
    }

    @Test fun botaoIniciarAbreEFechaOMenu() {
        ActivityScenario.launch(DesktopActivity::class.java).use {
            onView(withId(R.id.startMenuOverlay)).check(matches(withEffectiveVisibility(Visibility.GONE)))
            onView(withId(R.id.btnStart)).perform(click())
            onView(withId(R.id.startMenuOverlay)).check(matches(isDisplayed()))
            onView(withId(R.id.btnStart)).perform(click())
            onView(withId(R.id.startMenuOverlay)).check(matches(withEffectiveVisibility(Visibility.GONE)))
        }
    }

    @Test fun buscaSemResultadoMostraMensagem() {
        ActivityScenario.launch(DesktopActivity::class.java).use {
            onView(withId(R.id.btnStart)).perform(click())
            Thread.sleep(800) // dá tempo da lista carregar em coroutine
            onView(withId(R.id.editStartSearch)).perform(replaceText("zzzzzz-inexistente"))
            onView(withId(R.id.txtStartEmpty)).check(matches(isDisplayed()))
        }
    }
}
