package com.tvboxos.launcher

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tvboxos.launcher.data.AppDatabase
import com.tvboxos.launcher.data.DesktopIconEntity
import com.tvboxos.launcher.data.Profile
import com.tvboxos.launcher.util.IconOrder
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Room real (em memória): ordem por `position`, isolamento por perfil e persistência do arrastar. */
@RunWith(AndroidJUnit4::class)
class DesktopIconDaoTest {

    private lateinit var db: AppDatabase

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
    }

    @After fun tearDown() = db.close()

    private fun icon(profileId: Long, label: String, pos: Int) = DesktopIconEntity(
        profileId = profileId, label = label, packageName = "pkg.$label", activityClassName = null, position = pos
    )

    @Test fun listaVemOrdenadaPorPosition() = runBlocking {
        val dao = db.desktopIconDao()
        dao.insert(icon(1, "C", 2)); dao.insert(icon(1, "A", 0)); dao.insert(icon(1, "B", 1))
        assertEquals(listOf("A", "B", "C"), dao.getForProfile(1).map { it.label })
    }

    @Test fun iconesNaoVazamEntrePerfis() = runBlocking {
        val dao = db.desktopIconDao()
        dao.insert(icon(1, "A", 0)); dao.insert(icon(2, "X", 0))
        assertEquals(listOf("A"), dao.getForProfile(1).map { it.label })
        assertEquals(listOf("X"), dao.getForProfile(2).map { it.label })
    }

    @Test fun ordemArrastadaPersisteEFlowEmiteNovaOrdem() = runBlocking {
        val dao = db.desktopIconDao()
        listOf("A", "B", "C", "D").forEachIndexed { i, l -> dao.insert(icon(1, l, i)) }
        val before = dao.getForProfile(1)
        // usuário arrasta o primeiro ícone para a última posição
        val reordered = IconOrder.renumber(IconOrder.move(before, 0, 3))
        dao.updateAll(reordered)
        assertEquals(listOf("B", "C", "D", "A"), dao.observeForProfile(1).first().map { it.label })
    }

    @Test fun maxPositionDeListaVaziaEhNulo() = runBlocking {
        assertNull(db.desktopIconDao().maxPosition(99))
    }

    @Test fun atualizacoesPontuaisDeImagemNaoMexemNoRestoDoPerfil() = runBlocking {
        val dao = db.profileDao()
        val id = dao.insert(Profile(name = "Ana", avatarEmoji = "😀", passwordHash = "h", passwordSalt = "s",
            wallpaperPath = null, createdAt = 1L))
        dao.setWallpaperPath(id, "/x/wall.jpg")
        dao.setAvatarImagePath(id, "/x/av.jpg")
        val p = dao.getById(id)!!
        assertEquals("/x/wall.jpg", p.wallpaperPath)
        assertEquals("/x/av.jpg", p.avatarImagePath)
        assertEquals("h", p.passwordHash) // senha intacta
        assertEquals("Ana", p.name)
    }
}
