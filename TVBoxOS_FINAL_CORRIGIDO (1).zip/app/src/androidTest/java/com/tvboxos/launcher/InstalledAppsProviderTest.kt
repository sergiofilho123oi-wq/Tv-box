package com.tvboxos.launcher

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tvboxos.launcher.desktop.InstalledAppsProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InstalledAppsProviderTest {

    private val ctx get() = ApplicationProvider.getApplicationContext<android.content.Context>()

    @Test fun listaSemDuplicatasOrdenadaEsemOProprioLauncher() = runBlocking {
        val apps = InstalledAppsProvider.list(ctx)
        assertEquals(apps.size, apps.map { it.packageName }.toSet().size)
        assertEquals(apps.map { it.label.lowercase() }, apps.map { it.label.lowercase() }.sorted())
        assertFalse(apps.any { it.packageName == ctx.packageName })
    }

    @Test fun intentDeLancamentoUsaComponenteExplicito() {
        val i = InstalledAppsProvider.buildLaunchIntent("com.exemplo", "com.exemplo.Main")
        assertNotNull(i)
        assertEquals("com.exemplo", i!!.component!!.packageName)
        assertNull(InstalledAppsProvider.buildLaunchIntent("com.exemplo", null))
    }
}
