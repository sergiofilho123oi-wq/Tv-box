package com.tvboxos.launcher

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tvboxos.launcher.data.AppDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Garante que a migração 1→2 preserva perfis existentes (nunca apagar senhas/perfis numa atualização).
 * Usa SQLite puro em memória com o schema da versão 1.
 */
@RunWith(AndroidJUnit4::class)
class MigrationTest {

    @Test fun migracao1para2MantemDadosEAdicionaColuna() {
        val db = SQLiteDatabase.create(null)
        db.execSQL(
            "CREATE TABLE profiles (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, " +
                "avatarEmoji TEXT NOT NULL, passwordHash TEXT, passwordSalt TEXT, wallpaperPath TEXT, createdAt INTEGER NOT NULL)"
        )
        db.insert("profiles", null, ContentValues().apply {
            put("name", "Sérgio"); put("avatarEmoji", "😎"); put("passwordHash", "abc"); put("createdAt", 1L)
        })

        db.execSQL(AppDatabase.MIGRATION_1_2_SQL)

        db.rawQuery("SELECT name, passwordHash, avatarImagePath FROM profiles", null).use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("Sérgio", c.getString(0))
            assertEquals("abc", c.getString(1))
            assertTrue(c.isNull(2)) // nova coluna começa nula
        }
        db.close()
    }
}
