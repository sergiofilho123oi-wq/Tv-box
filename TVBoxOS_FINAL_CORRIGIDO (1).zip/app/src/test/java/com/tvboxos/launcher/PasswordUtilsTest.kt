package com.tvboxos.launcher

import com.tvboxos.launcher.util.PasswordUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordUtilsTest {
    @Test fun mesmoSaltEMesmaSenhaGeramMesmoHash() {
        val salt = PasswordUtils.generateSalt()
        assertEquals(PasswordUtils.hash("1234", salt), PasswordUtils.hash("1234", salt))
    }

    @Test fun senhaDiferenteGeraHashDiferente() {
        val salt = PasswordUtils.generateSalt()
        assertNotEquals(PasswordUtils.hash("1234", salt), PasswordUtils.hash("1235", salt))
    }

    @Test fun saltDiferenteGeraHashDiferente() {
        assertNotEquals(PasswordUtils.hash("1234", "aa"), PasswordUtils.hash("1234", "bb"))
    }

    @Test fun saltTem32CaracteresHexEEhAleatorio() {
        val a = PasswordUtils.generateSalt()
        assertEquals(32, a.length)
        assertTrue(a.all { it in '0'..'9' || it in 'a'..'f' })
        assertNotEquals(a, PasswordUtils.generateSalt())
    }

    @Test fun hashNuncaContemASenhaEmTextoPuro() {
        assertTrue(!PasswordUtils.hash("segredo", "aa").contains("segredo"))
    }
}
