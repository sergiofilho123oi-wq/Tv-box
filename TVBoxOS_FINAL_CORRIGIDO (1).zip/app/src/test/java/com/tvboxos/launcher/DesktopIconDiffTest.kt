package com.tvboxos.launcher

import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListUpdateCallback
import com.tvboxos.launcher.data.DesktopIconEntity
import com.tvboxos.launcher.desktop.DesktopIconDiffCallback
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DesktopIconDiffTest {
    private fun icon(id: Long, label: String = "i$id", pos: Int = id.toInt()) = DesktopIconEntity(
        id = id, profileId = 1, label = label, packageName = "p$id", activityClassName = null, position = pos
    )

    /** Registra as operações que o DiffUtil enviaria ao RecyclerView. */
    private class Recorder : ListUpdateCallback {
        val ops = mutableListOf<String>()
        override fun onInserted(position: Int, count: Int) { ops += "ins@$position x$count" }
        override fun onRemoved(position: Int, count: Int) { ops += "rem@$position x$count" }
        override fun onMoved(fromPosition: Int, toPosition: Int) { ops += "mov $fromPosition->$toPosition" }
        override fun onChanged(position: Int, count: Int, payload: Any?) { ops += "chg@$position x$count" }
    }

    private fun diff(old: List<DesktopIconEntity>, new: List<DesktopIconEntity>): List<String> {
        val rec = Recorder()
        DiffUtil.calculateDiff(DesktopIconDiffCallback(old, new)).dispatchUpdatesTo(rec)
        return rec.ops
    }

    @Test fun listasIguaisNaoGeramOperacao() {
        val l = listOf(icon(1), icon(2), icon(3))
        assertTrue(diff(l, l.map { it.copy() }).isEmpty())
    }

    @Test fun renomearRedesenhaApenasUmItem() {
        val old = listOf(icon(1), icon(2), icon(3))
        val new = listOf(icon(1), icon(2, label = "Novo"), icon(3))
        assertEquals(listOf("chg@1 x1"), diff(old, new))
    }

    @Test fun adicionarInsereNoFim() {
        val old = listOf(icon(1), icon(2))
        assertEquals(listOf("ins@2 x1"), diff(old, old + icon(3)))
    }

    @Test fun removerRemoveSomenteOItem() {
        val old = listOf(icon(1), icon(2), icon(3))
        assertEquals(listOf("rem@1 x1"), diff(old, listOf(icon(1), icon(3))))
    }
}
