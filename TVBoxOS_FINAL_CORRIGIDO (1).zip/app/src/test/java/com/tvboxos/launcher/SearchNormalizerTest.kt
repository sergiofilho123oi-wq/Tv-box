package com.tvboxos.launcher

import com.tvboxos.launcher.util.SearchNormalizer
import org.junit.Assert.assertEquals
import org.junit.Test

class SearchNormalizerTest {
    private val apps = listOf("Câmera", "Calculadora", "Configurações", "Netflix", "Galeria de Câmeras")

    @Test fun ignoraAcentoEMaiuscula() {
        assertEquals("camera", SearchNormalizer.normalize("  CÂMERA "))
        assertEquals("configuracoes", SearchNormalizer.normalize("Configurações"))
    }

    @Test fun consultaVaziaDevolveTudo() {
        assertEquals(apps, SearchNormalizer.filter(apps, "   ") { it })
    }

    @Test fun encontraSemDigitarAcento() {
        assertEquals(listOf("Câmera", "Galeria de Câmeras"), SearchNormalizer.filter(apps, "camera") { it })
    }

    @Test fun quemComecaVemAntesDeQuemApenasContem() {
        val r = SearchNormalizer.filter(listOf("Galeria de Câmeras", "Câmera"), "cam") { it }
        assertEquals(listOf("Câmera", "Galeria de Câmeras"), r)
    }

    @Test fun semResultado() {
        assertEquals(emptyList<String>(), SearchNormalizer.filter(apps, "zzz") { it })
    }
}
