package com.tvboxos.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Teste de regressão para erros de XML de recursos que só apareceriam no aapt2.
 * Caso real: `xmlns:app="http://schemas.android.com/apk/res/app"` (o correto é `res-auto`)
 * em activity_login.xml quebrou o build com "attribute app:layoutManager not found".
 * Roda como teste JVM comum: o diretório de trabalho do Gradle é o módulo `app`.
 */
class ResourceSanityTest {

    private val resDir: File =
        listOf(File("src/main/res"), File("app/src/main/res")).first { it.isDirectory }

    private fun xmlFiles(): List<File> =
        resDir.walkTopDown().filter { it.isFile && it.extension == "xml" }.toList()

    @Test fun existemArquivosDeRecurso() {
        assertTrue(xmlFiles().isNotEmpty())
    }

    @Test fun namespacesDeclaradosSaoValidos() {
        val allowed = setOf(
            "http://schemas.android.com/apk/res/android",
            "http://schemas.android.com/apk/res-auto",
            "http://schemas.android.com/tools"
        )
        val decl = Regex("xmlns:(\\w+)=\"([^\"]+)\"")
        val invalid = mutableListOf<String>()
        for (f in xmlFiles()) {
            for (m in decl.findAll(f.readText())) {
                if (m.groupValues[2] !in allowed) invalid.add(f.name + ": " + m.value)
            }
        }
        assertEquals("Namespaces inválidos: $invalid", emptyList<String>(), invalid)
    }

    @Test fun prefixosUsadosEstaoDeclarados() {
        val comments = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL)
        val usage = Regex("\\s(\\w+):\\w+\\s*=\\s*\"")
        val declaredRegex = Regex("xmlns:(\\w+)=")
        val problems = mutableListOf<String>()
        for (f in xmlFiles()) {
            val text = f.readText().replace(comments, "")
            val declared = declaredRegex.findAll(text).map { it.groupValues[1] }.toSet()
            val used = usage.findAll(text).map { it.groupValues[1] }.toSet() - "xmlns"
            val missing = used - declared
            if (missing.isNotEmpty()) problems.add(f.name + ": " + missing)
        }
        assertEquals("Prefixos sem xmlns: $problems", emptyList<String>(), problems)
    }
}
