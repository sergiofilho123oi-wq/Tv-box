package com.tvboxos.launcher

import com.tvboxos.launcher.util.ImageMath
import org.junit.Assert.assertEquals
import org.junit.Test

class ImageMathTest {
    @Test fun fotoDe12MpParaFullHdUsaSample2() {
        // 4000x3000 -> 2000x1500 ainda >= 1920x1080; 1000x750 já não serve
        assertEquals(2, ImageMath.inSampleSize(4000, 3000, 1920, 1080))
    }

    @Test fun imagemPequenaNaoReduz() {
        assertEquals(1, ImageMath.inSampleSize(800, 600, 1920, 1080))
    }

    @Test fun dimensoesInvalidasDevolvemUm() {
        assertEquals(1, ImageMath.inSampleSize(0, 0, 100, 100))
    }

    @Test fun fitWithinNaoAmplia() {
        assertEquals(800 to 600, ImageMath.fitWithin(800, 600, 1920, 1080))
    }

    @Test fun fitWithinMantemProporcao() {
        assertEquals(1440 to 1080, ImageMath.fitWithin(4000, 3000, 1920, 1080))
    }

    @Test fun quadradoCentral() {
        assertEquals(Triple(500, 0, 1000), ImageMath.centerSquare(2000, 1000))
        assertEquals(Triple(0, 250, 500), ImageMath.centerSquare(500, 1000))
    }
}
