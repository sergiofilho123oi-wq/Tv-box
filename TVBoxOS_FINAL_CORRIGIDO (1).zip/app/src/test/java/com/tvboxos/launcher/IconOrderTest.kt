package com.tvboxos.launcher

import com.tvboxos.launcher.data.DesktopIconEntity
import com.tvboxos.launcher.util.IconOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class IconOrderTest {
    private fun icon(id: Long, pos: Int) = DesktopIconEntity(
        id = id, profileId = 1, label = "i$id", packageName = "p$id", activityClassName = null, position = pos
    )
    private val base = listOf(icon(1, 0), icon(2, 1), icon(3, 2), icon(4, 3))

    @Test fun moveParaFrente() {
        assertEquals(listOf(2L, 3L, 1L, 4L), IconOrder.move(base, 0, 2).map { it.id })
    }

    @Test fun moveParaTras() {
        assertEquals(listOf(1L, 4L, 2L, 3L), IconOrder.move(base, 3, 1).map { it.id })
    }

    @Test fun indiceInvalidoNaoAltera() {
        assertSame(base, IconOrder.move(base, -1, 2))
        assertSame(base, IconOrder.move(base, 1, 9))
        assertSame(base, IconOrder.move(base, 2, 2))
    }

    @Test fun renumberGravaPositionSequencial() {
        val moved = IconOrder.move(base, 0, 3)
        val r = IconOrder.renumber(moved)
        assertEquals(listOf(0, 1, 2, 3), r.map { it.position })
        assertEquals(listOf(2L, 3L, 4L, 1L), r.map { it.id })
    }

    @Test fun renumberNaoMudaQuemJaEstaCerto() {
        val r = IconOrder.renumber(base)
        assertEquals(base, r)
    }
}
