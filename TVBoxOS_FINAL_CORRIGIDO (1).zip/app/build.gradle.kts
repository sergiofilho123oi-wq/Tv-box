plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.tvboxos.launcher"
    // compileSdk 33 cobre o Android 10 (API 29) do dispositivo-alvo com folga,
    // mas ainda usa APIs estáveis e bem suportadas em TV boxes antigas.
    compileSdk = 33

    defaultConfig {
        applicationId = "com.tvboxos.launcher"
        minSdk = 29 // Android 10, conforme hardware-alvo
        targetSdk = 30 // evita comportamentos mais recentes/pesados sem necessidade
        versionCode = 2
        versionName = "0.2.0-etapa2"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    testOptions {
        // Permite que testes JVM chamem APIs do android.jar sem estourar (retornam valores padrão).
        unitTests.isReturnDefaultValues = true
    }
}

ksp {
    // Necessário porque AppDatabase usa exportSchema = true (data/AppDatabase.kt).
    // Sem isso, o KSP do Room emite aviso/erro de schema não exportado.
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation("androidx.core:core-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    // Rotação correta de fotos da galeria (EXIF) ao definir papel de parede/avatar
    implementation("androidx.exifinterface:exifinterface:1.3.6")

    // Persistência local (perfis, ícones de desktop, preferências)
    implementation("androidx.room:room-runtime:2.5.2")
    implementation("androidx.room:room-ktx:2.5.2")
    ksp("androidx.room:room-compiler:2.5.2")

    // Testes JVM (rápidos, rodam no GitHub Actions): ./gradlew testDebugUnitTest
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")

    // Testes instrumentados (precisam de aparelho/emulador): ./gradlew connectedDebugAndroidTest
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test:runner:1.5.2")
    androidTestImplementation("androidx.test:rules:1.5.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    androidTestImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")
}
