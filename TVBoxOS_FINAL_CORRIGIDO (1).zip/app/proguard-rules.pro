# Regras de ProGuard/R8 do TVBox OS.
# minifyEnabled está desativado na Etapa 1 para facilitar debug.
# Quando for ativado (Etapa 5 - otimização), adicionar aqui regras
# para manter os modelos do Room (entidades) e reflection usada pelo Android.
-keep class com.tvboxos.launcher.data.** { *; }
