#!/usr/bin/env python3
"""Verificação estática do projeto Android (sem Gradle/SDK). Retorna 1 se achar problema."""
import os, re, sys
import xml.etree.ElementTree as ET
root = sys.argv[1]
res = os.path.join(root, 'app/src/main/res')
errors = []

# 1) XML bem formado
xmls = [os.path.join(d, f) for d, _, fs in os.walk(os.path.join(root, 'app/src')) for f in fs if f.endswith('.xml')]
for x in xmls:
    try:
        ET.parse(x)
    except ET.ParseError as e:
        errors.append(f'XML mal formado: {x}: {e}')

# 2) namespaces: qualquer xmlns apontando para apk/res/<algo> diferente de android/res-auto
for x in xmls:
    t = open(x, encoding='utf-8').read()
    for m in re.finditer(r'xmlns:(\w+)="([^"]+)"', t):
        pfx, uri = m.groups()
        if uri.startswith('http://schemas.android.com/apk/res') and uri not in (
                'http://schemas.android.com/apk/res/android', 'http://schemas.android.com/apk/res-auto'):
            errors.append(f'namespace inválido {pfx}={uri} em {x}')
    # prefixo usado sem declaração
    declared = set(re.findall(r'xmlns:(\w+)=', t))
    body = re.sub(r'<!--.*?-->', '', t, flags=re.S)
    used = set(re.findall(r'\b(\w+):[A-Za-z_]+\s*=\s*"', body)) - {'xmlns'}
    for u in used - declared:
        errors.append(f'prefixo "{u}:" usado sem xmlns em {x}')

# 3) recursos definidos no projeto
defined = {k: set() for k in ['id','layout','string','drawable','menu','color','mipmap','style']}
for d, _, fs in os.walk(res):
    base = os.path.basename(d)
    for f in fs:
        if not f.endswith('.xml'): continue
        p = os.path.join(d, f); name = f[:-4]; t = open(p, encoding='utf-8').read()
        if base.startswith('layout'): defined['layout'].add(name)
        elif base.startswith('drawable'): defined['drawable'].add(name)
        elif base.startswith('menu'): defined['menu'].add(name)
        elif base.startswith('mipmap'): defined['mipmap'].add(name)
        for m in re.finditer(r'@\+id/(\w+)', t): defined['id'].add(m.group(1))
        if base.startswith('values'):
            for tag, kind in (('string','string'),('color','color'),('style','style')):
                for m in re.finditer(rf'<{tag}\s+name="([\w.]+)"', t):
                    defined[kind].add(m.group(1).replace('.', '_') if kind=='style' else m.group(1))
# mipmap também conta como drawable para @drawable? não — mantém separado.

# 4) referências @tipo/nome em XML
for x in xmls:
    if '/res/' not in x: continue
    t = re.sub(r'<!--.*?-->', '', open(x, encoding='utf-8').read(), flags=re.S)
    for m in re.finditer(r'@(?!android:)(\+?)(id|layout|string|drawable|menu|color|mipmap|style)/([\w.]+)', t):
        plus, kind, name = m.groups()
        key = name.replace('.', '_') if kind == 'style' else name
        if plus: continue
        # style com parent implícito (TVBoxButton.Outline) -> nome com '.'
        if key not in defined[kind] and name not in defined[kind]:
            errors.append(f'referência quebrada @{kind}/{name} em {os.path.relpath(x, root)}')

# 5) referências R.tipo.nome em Kotlin (main + androidTest + test)
for d, _, fs in os.walk(os.path.join(root, 'app/src')):
    for f in fs:
        if not f.endswith('.kt'): continue
        p = os.path.join(d, f); t = open(p, encoding='utf-8').read()
        # package vs pasta
        m = re.search(r'^package\s+([\w.]+)', t, re.M)
        if m:
            exp = m.group(1).replace('.', '/')
            if not os.path.dirname(p).endswith(exp) and '/test/' not in p and '/androidTest/' not in p:
                errors.append(f'package {m.group(1)} não bate com a pasta: {p}')
        for m in re.finditer(r'(?<![\w.])R\.(id|layout|string|drawable|menu|color|mipmap)\.(\w+)', t):
            kind, name = m.groups()
            if name not in defined[kind]:
                errors.append(f'R.{kind}.{name} sem recurso, em {os.path.relpath(p, root)}')
        # chaves/parênteses balanceados (ignorando strings/comentários simples)
        s = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', t)
        s = re.sub(r'//.*', '', s); s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
        s = re.sub(r"'(?:\\.|[^'\\])'", "''", s)
        for o, c in ('{}', '()', '[]'):
            if s.count(o) != s.count(c):
                errors.append(f'{o}{c} desbalanceado em {os.path.relpath(p, root)} ({s.count(o)} vs {s.count(c)})')

# 6) ids usados em findViewById/withId existem em algum layout/menu
for d, _, fs in os.walk(os.path.join(root, 'app/src')):
    for f in fs:
        if f.endswith('.kt'):
            t = open(os.path.join(d, f), encoding='utf-8').read()
            for m in re.finditer(r'R\.id\.(\w+)', t):
                if m.group(1) not in defined['id']:
                    errors.append(f'R.id.{m.group(1)} não definido ({f})')

# 7) wrapper
for f in ['gradlew','gradlew.bat','gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.properties']:
    if not os.path.isfile(os.path.join(root, f)): errors.append(f'wrapper: falta {f}')
if os.path.isfile(os.path.join(root,'gradlew')):
    if b'\r' in open(os.path.join(root,'gradlew'),'rb').read(): errors.append('gradlew com CRLF')
    if not os.access(os.path.join(root,'gradlew'), os.X_OK): errors.append('gradlew sem permissão de execução')

print(f'XMLs: {len(xmls)} | recursos: ' + ', '.join(f'{k}={len(v)}' for k, v in defined.items()))
if errors:
    print('PROBLEMAS:'); [print(' -', e) for e in errors]; sys.exit(1)
print('OK: nenhum problema encontrado pela verificação estática.')
