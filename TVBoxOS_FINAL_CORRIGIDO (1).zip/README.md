# TVBox OS

Launcher Android com visual inspirado no Windows 11, feito para rodar em TV Box
Android (ver hardware-alvo e detalhes completos em `CONTINUAR_PROJETO.md`).

## Abrir o projeto
1. Instale o **Android Studio** (recomendado: Hedgehog ou mais recente).
2. Abra esta pasta (`TVBoxOS/`) em "Open an existing project".
3. O wrapper do Gradle já vem incluído no projeto (ver nota abaixo).
4. Deixe o Gradle sincronizar (primeira vez baixa as dependências pela internet).

### Gradle Wrapper e JDK
O wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`) já está incluído e aponta para o
Gradle 8.4. **Use JDK 17** (o Gradle 8.4 não roda em JDK 21). O workflow do GitHub Actions já usa JDK 17.

## Compilar o APK
Com o projeto sincronizado no Android Studio:
- **Build > Build Bundle(s) / APK(s) > Build APK(s)**, ou
- pela linha de comando: `./gradlew assembleDebug`
  (gera em `app/build/outputs/apk/debug/app-debug.apk`).

## Instalar na TV Box
1. Ative "Fontes desconhecidas" / instalação de apps fora da loja, nas
   configurações do Android da TV Box.
2. Copie o APK para a TV Box (USB, rede local ou um gerenciador de arquivos) e
   instale-o.
3. Para usar como tela inicial: Configurações do Android > Apps padrão >
   Tela inicial (Launcher/Home) > escolha **TVBox OS**.

Veja `CONTINUAR_PROJETO.md` para o estado detalhado do desenvolvimento.

## Testes
- Unitários (JVM, sem aparelho): `./gradlew testDebugUnitTest`
- Instrumentados (aparelho/emulador conectado): `./gradlew connectedDebugAndroidTest`
