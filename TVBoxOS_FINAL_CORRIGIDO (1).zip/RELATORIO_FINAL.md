# RELATÓRIO FINAL — TVBox OS (0.2.0-etapa2)

Data: 23/11/2026

## 1. Resposta direta

| Pergunta | Resposta |
|---|---|
| A compilação foi concluída? | **Não foi executada.** Não existe resultado de BUILD SUCCESSFUL. |
| O APK foi gerado? | **Não.** Nenhum APK foi gerado nem está no ZIP. |
| Os testes foram executados? | **Não.** Nem os JVM nem os instrumentados. |
| Há erros conhecidos pendentes? | Nenhum conhecido. Mas Kotlin, KSP/Room e testes nunca rodaram em lugar nenhum, então podem existir erros ainda desconhecidos. |

**Limitação externa:** o ambiente em que trabalhei não tem rede (Gradle, Google Maven, Maven Central e GitHub não respondem), nem Android SDK, nem compilador Kotlin. Tentei de novo nesta rodada e o resultado foi o mesmo. A validação real é a próxima execução do GitHub Actions.

Observação: o ZIP "TVBoxOS_repo_corrigido.zip" citado na mensagem não chegou como anexo. Trabalhei a partir do projeto já corrigido por mim na rodada anterior (mesmo conteúdo).

## 2. Problemas encontrados

| # | Problema | Gravidade | Como foi identificado |
|---|---|---|---|
| 1 | `activity_login.xml`: `xmlns:app="…/apk/res/app"` (o correto é `res-auto`) e atributo inexistente `app:layoutManagerOrientation` | Bloqueante | Log real do Actions (`processDebugResources`) |
| 2 | Variável local chamada `final` em `ImageStorage.kt` | Risco baixo | Revisão do código |
| 3 | Heap do Gradle de 2 GB para Kotlin + KSP + D8 | Risco médio | Revisão da configuração |
| 4 | `.gitignore` não ignorava `app/build` | Higiene | Revisão |
| 5 | Workflow antigo (que o log mostra) extraía um `.zip` commitado para `./project` | Configuração | Log do Actions |
| 6 | Nada protegia contra XML de recursos inválido antes do aapt2 | Prevenção | Consequência do item 1 |

Não encontrei outros erros em: Manifest, dependências, versões de ferramentas, Room/DAOs/entidades, imports internos (0 quebrados), referências `R.*` e `@recurso` (0 quebradas), wrapper do Gradle.

## 3. Correções realizadas

1. `activity_login.xml`: removidos o `xmlns:app` e os dois atributos `app:` inválidos, além do `android:orientation` sem efeito. A orientação horizontal continua sendo definida em `LoginActivity.kt`. Funcionalidade preservada.
2. `ImageStorage.kt`: `final` renomeado para `scaledAvatar` (mesmo comportamento).
3. `gradle.properties`: `-Xmx3072m` e `kotlin.daemon.jvmargs=-Xmx2048m`.
4. `gradle-wrapper.properties`: `networkTimeout` e `validateDistributionUrl` (Gradle continua 8.4).
5. `.gitignore`: ignora `build/` em qualquer módulo, `.kotlin/`, `*.apk`, `*.aab`.
6. Novo `ResourceSanityTest` (teste JVM) e `tools/check_project.py` (verificação estática).
7. `.github/workflows/android.yml` reescrito, na ordem:
   1. checkout
   2. verificação dos 8 arquivos obrigatórios e do wrapper (mensagem clara se faltar algo)
   3. `chmod +x gradlew` (antes de qualquer uso)
   4. verificação estática (só roda se `tools/check_project.py` existir)
   5. JDK 17 (Temurin, `setup-java@v5`)
   6. Android SDK, licenças aceitas sem interação, `platforms;android-33` e `build-tools;33.0.2`
   7. cache do Gradle
   8. **`./gradlew clean testDebugUnitTest assembleDebug --no-daemon --console=plain --stacktrace`**
   9. confirmação do APK (`ls`)
   10. upload do APK (falha se não existir), do relatório de testes e dos schemas do Room (esses dois sempre, mesmo com falha)

Nenhum teste foi desativado e nenhuma funcionalidade da Etapa 2 foi removida ou alterada.

## 4. Testes executados e resultado real

| Verificação | Executada? | Resultado |
|---|---|---|
| `./gradlew clean testDebugUnitTest assembleDebug` | **Não** (sem rede/SDK) | — |
| Testes JVM: `DesktopIconDiffTest`, `IconOrderTest`, `ImageMathTest`, `PasswordUtilsTest`, `SearchNormalizerTest`, `ResourceSanityTest` | **Não** | — (valores esperados conferidos à mão contra o código; consistentes) |
| Testes instrumentados (4 arquivos) | **Não** (precisam de aparelho/emulador) | — |
| 31 XMLs bem formados | Sim | OK |
| Namespaces e prefixos dos XMLs | Sim | Original: 1 erro (o do login). Atual: OK |
| Referências `@recurso` e `R.*` (main/test/androidTest) | Sim | 0 quebradas; provei que o verificador detecta erro injetado |
| Imports internos das classes do projeto | Sim | 0 quebrados |
| Imports externos x dependências declaradas | Sim (leitura) | Todos cobertos (`activity` e `sqlite` vêm transitivamente de appcompat/room) |
| `package` x pasta; chaves/parênteses balanceados | Sim | OK |
| Wrapper: 4 arquivos, `gradlew` sem CRLF e executável, `.jar` íntegro | Sim | OK |
| YAML do workflow e ordem das etapas | Sim | Válido |
| Lógica do `ResourceSanityTest` simulada em Python | Sim | Falha no original, passa no corrigido (**não** é execução no Gradle) |

Evidência real do CI anterior: Gradle 8.4, JDK 17, SDK, plugins, manifesto e `checkDebugAarMetadata` passaram. O build parou em `processDebugResources` (item 1). Compilação Kotlin, KSP, D8 e testes não chegaram a rodar.

## 5. Dependem de teste no dispositivo físico (TV Box)

- Seletor de imagens (DocumentsUI): algumas TV boxes não o trazem (o app avisa em vez de quebrar).
- Navegação por controle remoto/teclado e tecla MENU; mouse USB (clique direito).
- Arrastar e reordenar ícones; menu "Mover para trás/frente".
- Desempenho e memória com papel de parede 1920x1080 e lista de apps na GPU Mali-450 / 4 GB.
- Definir o TVBox OS como launcher padrão (categoria HOME).
- Testes instrumentados (`./gradlew connectedDebugAndroidTest`).

## 6. Observações não alteradas (preservar comportamento)

`allowBackup="true"` (inclui o hash de senha nos backups); hash SHA-256 de uma rodada; ícone de cadeado do perfil nunca exibido; `MigrationTest` valida só o SQL; textos fixos em alguns toasts; avatar pode ser decodificado na thread principal (com cache).

## 7. Próximo passo

1. Extraia o ZIP na **raiz** do repositório. Apague qualquer `.zip` do projeto commitado e workflows antigos em `.github/workflows/`.
2. `git add -A && git commit -m "Correções de build" && git push`.
3. Veja o Actions. Se falhar, envie o log: a seção "What went wrong" indica arquivo e linha.
4. Se passar, baixe o artefato `tvboxos-debug-apk` e commite `app/schemas/` (artefato `tvboxos-room-schemas`).
